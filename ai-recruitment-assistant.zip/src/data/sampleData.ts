import type { Candidate, InterviewQuestion, JobRole, SampleCandidatePreset } from "../types/recruitment";

export const INITIAL_JOB_ROLES: JobRole[] = [
  {
    id: "role-pm-01",
    title: "Product Manager",
    department: "Product & Strategy",
    experienceLevel: "Mid-Senior (4–6 years)",
    workMode: "Hybrid",
    summary:
      "Lead cross-functional product discovery, roadmap prioritization, and B2B workflow launches in partnership with engineering, design, and customer success.",
    responsibilities: [
      "Define quarterly product roadmaps backed by customer interviews and usage metrics.",
      "Write clear product requirement documents and align engineering and UX sprints.",
      "Track activation, retention, and funnel conversion KPIs post-launch.",
      "Collaborate with sales and enterprise stakeholders on go-to-market readiness.",
    ],
    requiredSkills: [
      "Product Strategy",
      "Roadmap Prioritization",
      "SQL & Funnel Analytics",
      "Stakeholder Management",
      "Agile Delivery",
    ],
    preferredQualifications: [
      "MBA or equivalent experience in B2B SaaS products",
      "Experience conducting structured user research and A/B experiments",
    ],
    createdAt: "2026-11-18",
  },
  {
    id: "role-swe-02",
    title: "Software Engineer",
    department: "Engineering",
    experienceLevel: "Mid-Level (2–5 years)",
    workMode: "Hybrid",
    summary:
      "Design, build, and maintain reliable web services and customer-facing TypeScript applications with strong automated test coverage.",
    responsibilities: [
      "Develop modular TypeScript/React interfaces and scalable Node.js REST APIs.",
      "Review pull requests, optimize database queries, and improve system latency.",
      "Partner with product designers to ship accessible, responsive UI workflows.",
      "Participate in on-call reliability reviews and post-incident improvements.",
    ],
    requiredSkills: [
      "TypeScript",
      "React",
      "Node.js",
      "REST APIs",
      "PostgreSQL / SQL",
      "Unit & Integration Testing",
    ],
    preferredQualifications: [
      "Experience with cloud deployments and CI/CD pipelines",
      "Familiarity with performance profiling and observability tools",
    ],
    createdAt: "2026-11-19",
  },
  {
    id: "role-hrbp-03",
    title: "HR Business Partner",
    department: "People & Talent",
    experienceLevel: "Mid-Level (3–5 years)",
    workMode: "On-site",
    summary:
      "Partner with business unit leaders on talent planning, performance cycles, employee engagement, and structured hiring governance.",
    responsibilities: [
      "Advise department heads on workforce planning, retention, and org design.",
      "Run structured performance review calibrations and manager coaching sessions.",
      "Audit hiring rubrics to ensure consistent, fair, human-led candidate decisions.",
      "Lead quarterly employee engagement surveys and action-plan follow-through.",
    ],
    requiredSkills: [
      "Workforce Planning",
      "Employee Relations",
      "Performance Management",
      "HR Analytics",
      "Talent Acquisition Governance",
    ],
    preferredQualifications: [
      "MBA in Human Resources or Organizational Behavior",
      "Experience implementing competency-based interview frameworks",
    ],
    createdAt: "2026-11-20",
  },
  {
    id: "role-fa-04",
    title: "Financial Analyst",
    department: "Finance & FP&A",
    experienceLevel: "Associate (1–3 years)",
    workMode: "Hybrid",
    summary:
      "Support monthly budgeting, variance forecasting, unit-economics modeling, and executive board reporting across operating teams.",
    responsibilities: [
      "Build three-statement financial models and monthly budget-vs-actual dashboards.",
      "Analyze departmental spend, SaaS gross margins, and customer acquisition payback.",
      "Prepare clear executive summaries for CFO and leadership reviews.",
      "Partner with department leads during annual operating plan cycles.",
    ],
    requiredSkills: [
      "Financial Modeling",
      "Excel & Pivot Reporting",
      "Variance Analysis",
      "Forecasting",
      "Executive Communication",
    ],
    preferredQualifications: [
      "MBA Finance, CFA Level I/II, or Chartered Accountant track",
      "Working knowledge of SQL or BI visualization tools",
    ],
    createdAt: "2026-11-21",
  },
];

export const INITIAL_CANDIDATES: Candidate[] = [
  {
    id: "cand-101",
    name: "Ananya Deshmukh",
    email: "ananya.deshmukh@example.com",
    currentRole: "Associate Product Manager",
    targetRole: "Product Manager",
    experienceYears: 4.5,
    education: "MBA Strategy, IIM Indore",
    location: "Bengaluru",
    skills: [
      "Product Strategy",
      "SQL & Funnel Analytics",
      "User Research",
      "Agile Delivery",
      "Stakeholder Management",
    ],
    resumeSummary:
      "Led onboarding redesign for a B2B payments platform serving 18,000 SMBs, lifting 30-day activation by 19%. Strong SQL and cross-functional sprint ownership.",
    aiMatchScore: 91,
    hrScore: 88,
    hrDecision: "Shortlisted",
    aiAdvisoryNote:
      "Strong alignment with core product discovery, SQL analytics, and stakeholder management criteria.",
    evaluation: {
      interviewerName: "Meera Kulkarni (HR Lead)",
      interviewDate: "2026-11-20",
      ratings: {
        roleCompetence: 5,
        communication: 5,
        problemSolving: 4,
        cultureFit: 4,
        leadership: 4,
      },
      overallHrScore: 88,
      strengths: "Crisp product sense, structured metrics framing, calm stakeholder negotiation.",
      concerns: "Limited direct enterprise pricing experience; probe in panel round.",
      decision: "Shortlisted",
      submittedAt: "2026-11-20",
    },
  },
  {
    id: "cand-102",
    name: "Rohan Mehta",
    email: "rohan.mehta@example.com",
    currentRole: "Full Stack Developer",
    targetRole: "Software Engineer",
    experienceYears: 3.5,
    education: "B.Tech Computer Science, NIT Surat",
    location: "Pune",
    skills: ["TypeScript", "React", "Node.js", "PostgreSQL / SQL", "REST APIs"],
    resumeSummary:
      "3.5 years building SaaS dashboards in React and Node.js. Reduced API p95 latency by 38% via indexing and query batching. Writes Jest integration tests.",
    aiMatchScore: 89,
    hrScore: 84,
    hrDecision: "Proceed to Offer",
    aiAdvisoryNote:
      "Covers all required full-stack TypeScript and SQL skills with measurable latency outcomes.",
    evaluation: {
      interviewerName: "Vikram Nair (Engineering HR)",
      interviewDate: "2026-11-21",
      ratings: {
        roleCompetence: 5,
        communication: 4,
        problemSolving: 4,
        cultureFit: 4,
        leadership: 4,
      },
      overallHrScore: 84,
      strengths: "Solid system debugging clarity and clean API design habits.",
      concerns: "None blocking; ready for final compensation conversation.",
      decision: "Proceed to Offer",
      submittedAt: "2026-11-21",
    },
  },
  {
    id: "cand-103",
    name: "Priya Nair",
    email: "priya.nair@example.com",
    currentRole: "People Operations Specialist",
    targetRole: "HR Business Partner",
    experienceYears: 4.0,
    education: "MBA Human Resources, XLRI",
    location: "Mumbai",
    skills: [
      "Employee Relations",
      "Performance Management",
      "HR Analytics",
      "Workforce Planning",
    ],
    resumeSummary:
      "Managed annual appraisal calibration for 220 corporate staff, redesigned onboarding checklists, and partnered with hiring managers on structured interview rubrics.",
    aiMatchScore: 86,
    hrScore: null,
    hrDecision: "Pending Review",
    aiAdvisoryNote:
      "Strong HRBP fundamentals and MBA HR pedigree; schedule HR panel to assess org-design depth.",
  },
  {
    id: "cand-104",
    name: "Kabir Malhotra",
    email: "kabir.malhotra@example.com",
    currentRole: "Junior Business Analyst",
    targetRole: "Financial Analyst",
    experienceYears: 2.0,
    education: "B.Com (Hons), Delhi University",
    location: "Gurugram",
    skills: ["Excel & Pivot Reporting", "Variance Analysis", "Power BI", "Forecasting"],
    resumeSummary:
      "Supported monthly revenue variance reporting and cost-center tracking for a 140-person logistics division. Built automated Excel budget templates.",
    aiMatchScore: 78,
    hrScore: 72,
    hrDecision: "Hold",
    aiAdvisoryNote:
      "Good variance reporting foundation; three-statement modeling depth needs verification.",
    evaluation: {
      interviewerName: "Meera Kulkarni (HR Lead)",
      interviewDate: "2026-11-19",
      ratings: {
        roleCompetence: 4,
        communication: 4,
        problemSolving: 3,
        cultureFit: 4,
        leadership: 3,
      },
      overallHrScore: 72,
      strengths: "Accurate spreadsheet hygiene and collaborative attitude.",
      concerns: "Hesitated on SaaS unit economics case during interview.",
      decision: "Hold",
      submittedAt: "2026-11-19",
    },
  },
  {
    id: "cand-105",
    name: "Siddharth Iyer",
    email: "siddharth.iyer@example.com",
    currentRole: "Frontend Engineer",
    targetRole: "Software Engineer",
    experienceYears: 2.5,
    education: "B.E. Information Technology, Mumbai University",
    location: "Mumbai",
    skills: ["React", "TypeScript", "Tailwind CSS", "REST APIs"],
    resumeSummary:
      "Built responsive customer portals in React and TypeScript. Light backend exposure with Express; eager to expand into relational database modeling.",
    aiMatchScore: 74,
    hrScore: null,
    hrDecision: "Pending Review",
    aiAdvisoryNote:
      "Strong UI skills; missing deeper PostgreSQL and backend testing experience listed in JD.",
  },
  {
    id: "cand-106",
    name: "Neha Chatterjee",
    email: "neha.chatterjee@example.com",
    currentRole: "Marketing Operations Lead",
    targetRole: "Product Manager",
    experienceYears: 3.0,
    education: "MBA Marketing, NMIMS",
    location: "Hyderabad",
    skills: ["Stakeholder Management", "Campaign Analytics", "A/B Testing", "CRM"],
    resumeSummary:
      "Owned lifecycle CRM journeys and funnel conversion reporting across web and mobile apps. Transitioning into core product management.",
    aiMatchScore: 64,
    hrScore: 60,
    hrDecision: "Not Selected",
    aiAdvisoryNote:
      "Strong GTM and funnel awareness, but lacks direct engineering sprint and SQL roadmap ownership.",
    evaluation: {
      interviewerName: "Meera Kulkarni (HR Lead)",
      interviewDate: "2026-11-18",
      ratings: {
        roleCompetence: 3,
        communication: 4,
        problemSolving: 3,
        cultureFit: 3,
        leadership: 2,
      },
      overallHrScore: 60,
      strengths: "Articulate communicator with strong customer empathy.",
      concerns: "Not ready for mid-senior PM technical scoping expectations.",
      decision: "Not Selected",
      submittedAt: "2026-11-18",
    },
  },
];

export const SAMPLE_SCREENING_PRESETS: SampleCandidatePreset[] = [
  {
    label: "Aarav Sharma · PM Profile",
    name: "Aarav Sharma",
    currentRole: "Product Analyst",
    experienceYears: 4,
    education: "MBA Product & Strategy",
    skills: "Product Strategy, SQL, Roadmap Prioritization, A/B Testing, Jira, Stakeholder Alignment",
    resumeSummary:
      "4 years in fintech product teams. Led checkout conversion experiments across Android and web, improving completion by 14%. Regularly writes PRDs, queries PostgreSQL with SQL, and runs weekly sprint grooming with 8 engineers.",
    suggestedRoleTitle: "Product Manager",
  },
  {
    label: "Divya Menon · Engineer Profile",
    name: "Divya Menon",
    currentRole: "Backend Developer",
    experienceYears: 3,
    education: "B.Tech Computer Science",
    skills: "Node.js, TypeScript, PostgreSQL, REST APIs, Docker, Jest Testing",
    resumeSummary:
      "3 years building RESTful microservices in Node.js and TypeScript with PostgreSQL. Designed automated Jest integration suites and reduced deployment rollbacks. Basic familiarity with React components.",
    suggestedRoleTitle: "Software Engineer",
  },
  {
    label: "Karan Verma · HR Profile",
    name: "Karan Verma",
    currentRole: "Talent Acquisition Associate",
    experienceYears: 3.5,
    education: "MBA Human Resources",
    skills: "Talent Acquisition Governance, Employee Relations, HR Analytics, Onboarding, Excel",
    resumeSummary:
      "3.5 years partnering with tech and sales managers on structured hiring, campus recruitment, and 90-day onboarding retention programs. Tracked offer acceptance ratios and built monthly HR dashboards.",
    suggestedRoleTitle: "HR Business Partner",
  },
];

export const INITIAL_INTERVIEW_QUESTIONS: InterviewQuestion[] = [
  {
    id: "q-1",
    category: "Product Strategy",
    question:
      "Tell me about a time you had to deprioritize a high-visibility feature requested by leadership. How did you communicate the trade-off?",
    whatToLookFor:
      "Look for data-backed reasoning, clear customer impact framing, and respectful alignment without burning stakeholder trust.",
  },
  {
    id: "q-2",
    category: "Analytical & Metrics",
    question:
      "Activation dropped 12% after a mobile onboarding update. Walk me through how you would diagnose the root cause in the first 48 hours.",
    whatToLookFor:
      "Expect structured funnel segmentation (OS, step drop-off, cohort), SQL/telemetry checks, and hypothesis validation before rolling back.",
  },
  {
    id: "q-3",
    category: "Execution & Agile",
    question:
      "Describe a launch where engineering complexity doubled mid-sprint. How did you adjust scope while protecting the core user outcome?",
    whatToLookFor:
      "Assesses practical MVP scoping, collaborative partnership with engineers, and clarity under delivery pressure.",
  },
  {
    id: "q-4",
    category: "Behavioral & Collaboration",
    question:
      "Share an example of resolving a disagreement between Design and Engineering on a user workflow.",
    whatToLookFor:
      "Evidence of active listening, shared user-outcome goals, and fair trade-off documentation.",
  },
  {
    id: "q-5",
    category: "Leadership & Ownership",
    question:
      "What is a product metric you personally owned that missed its quarterly target, and what did you change afterward?",
    whatToLookFor:
      "Accountability without blame-shifting, concrete post-mortem learnings, and measurable follow-up changes.",
  },
];
