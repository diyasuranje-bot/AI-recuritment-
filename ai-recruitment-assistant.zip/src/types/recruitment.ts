export type TabKey =
  | "home"
  | "jd"
  | "screening"
  | "shortlist"
  | "questions"
  | "evaluation";

export type HrDecision =
  | "Pending Review"
  | "Shortlisted"
  | "Proceed to Offer"
  | "Hold"
  | "Not Selected";

export interface JobRole {
  id: string;
  title: string;
  department: string;
  experienceLevel: string;
  workMode: string;
  summary: string;
  responsibilities: string[];
  requiredSkills: string[];
  preferredQualifications: string[];
  createdAt: string;
}

export interface ScreeningResult {
  matchScore: number;
  advisoryLabel: "Strong Fit" | "Moderate Fit" | "Needs Review";
  matchedSkills: string[];
  missingSkills: string[];
  strengths: string[];
  interviewProbes: string[];
  hrAdvisorySummary: string;
}

export interface CandidateEvaluationRecord {
  interviewerName: string;
  interviewDate: string;
  ratings: {
    roleCompetence: number;
    communication: number;
    problemSolving: number;
    cultureFit: number;
    leadership: number;
  };
  overallHrScore: number;
  strengths: string;
  concerns: string;
  decision: HrDecision;
  submittedAt: string;
}

export interface Candidate {
  id: string;
  name: string;
  email: string;
  currentRole: string;
  targetRole: string;
  experienceYears: number;
  education: string;
  location: string;
  skills: string[];
  resumeSummary: string;
  aiMatchScore: number;
  hrScore: number | null;
  hrDecision: HrDecision;
  aiAdvisoryNote: string;
  evaluation?: CandidateEvaluationRecord;
}

export interface InterviewQuestion {
  id: string;
  category: string;
  question: string;
  whatToLookFor: string;
}

export interface SampleCandidatePreset {
  label: string;
  name: string;
  currentRole: string;
  experienceYears: number;
  education: string;
  skills: string;
  resumeSummary: string;
  suggestedRoleTitle: string;
}
