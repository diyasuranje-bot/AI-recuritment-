import { useEffect, useState } from "react";
import {
  ChevronLeft,
  ClipboardCheck,
  FileText,
  HelpCircle,
  Home,
  RotateCcw,
  Table2,
  UserCheck,
} from "lucide-react";
import CandidateEvaluation from "./components/CandidateEvaluation";
import CandidateShortlisting from "./components/CandidateShortlisting";
import HomeView from "./components/HomeView";
import InterviewQuestionsGenerator from "./components/InterviewQuestionsGenerator";
import JobDescriptionGenerator from "./components/JobDescriptionGenerator";
import ResumeScreening from "./components/ResumeScreening";
import { INITIAL_CANDIDATES, INITIAL_JOB_ROLES } from "./data/sampleData";
import type {
  Candidate,
  CandidateEvaluationRecord,
  HrDecision,
  JobRole,
  TabKey,
} from "./types/recruitment";

const STORAGE_KEYS = {
  roles: "ai_recruiter_roles_v1",
  candidates: "ai_recruiter_candidates_v1",
};

const TAB_TITLES: Record<TabKey, string> = {
  home: "AI Recruitment Assistant",
  jd: "Job Description Generator",
  screening: "Resume Screening",
  shortlist: "Candidate Shortlisting",
  questions: "Interview Questions",
  evaluation: "Candidate Evaluation",
};

const TAB_SUBTITLES: Record<TabKey, string> = {
  home: "Executive Overview & Pipeline",
  jd: "Structured Role Drafting",
  screening: "Candidate-to-Role Comparison",
  shortlist: "Scores & Human Decisions",
  questions: "Panel Question Guides",
  evaluation: "Competency Scoring Form",
};

const SIDEBAR_ITEMS: Array<{
  key: TabKey;
  label: string;
  icon: typeof Home;
}> = [
  { key: "home", label: "Home", icon: Home },
  { key: "jd", label: "Job Descriptions", icon: FileText },
  { key: "screening", label: "Resume Screening", icon: UserCheck },
  { key: "shortlist", label: "Shortlist Table", icon: Table2 },
  { key: "questions", label: "Interview Questions", icon: HelpCircle },
  { key: "evaluation", label: "Candidate Evaluation", icon: ClipboardCheck },
];

function BrandEmblem() {
  return (
    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-teal-700 text-white">
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="h-4.5 w-4.5"
        aria-hidden="true"
      >
        <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
        <circle cx="9" cy="7" r="4" />
        <polyline points="16 11 18 13 22 9" />
      </svg>
    </div>
  );
}

export default function App() {
  const [activeTab, setActiveTab] = useState<TabKey>("home");
  const [roles, setRoles] = useState<JobRole[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.roles);
      return saved ? JSON.parse(saved) : INITIAL_JOB_ROLES;
    } catch {
      return INITIAL_JOB_ROLES;
    }
  });

  const [candidates, setCandidates] = useState<Candidate[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.candidates);
      return saved ? JSON.parse(saved) : INITIAL_CANDIDATES;
    } catch {
      return INITIAL_CANDIDATES;
    }
  });

  const [preselectedScreeningRole, setPreselectedScreeningRole] = useState<string | undefined>(
    undefined
  );
  const [selectedEvalCandidateId, setSelectedEvalCandidateId] = useState<string>(
    INITIAL_CANDIDATES[0].id
  );

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.roles, JSON.stringify(roles));
    } catch {
      // Ignore storage quota errors
    }
  }, [roles]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.candidates, JSON.stringify(candidates));
    } catch {
      // Ignore storage quota errors
    }
  }, [candidates]);

  const handleSaveRole = (newRole: JobRole) => {
    setRoles((prev) => {
      const exists = prev.some(
        (r) => r.title.toLowerCase() === newRole.title.toLowerCase()
      );
      if (exists) {
        return prev.map((r) =>
          r.title.toLowerCase() === newRole.title.toLowerCase() ? newRole : r
        );
      }
      return [newRole, ...prev];
    });
  };

  const handleAddCandidateToShortlist = (newCandidate: Candidate) => {
    setCandidates((prev) => [newCandidate, ...prev]);
    setSelectedEvalCandidateId(newCandidate.id);
  };

  const handleUpdateDecision = (candidateId: string, decision: HrDecision) => {
    setCandidates((prev) =>
      prev.map((c) => (c.id === candidateId ? { ...c, hrDecision: decision } : c))
    );
  };

  const handleSaveEvaluation = (
    candidateId: string,
    evaluation: CandidateEvaluationRecord
  ) => {
    setCandidates((prev) =>
      prev.map((c) =>
        c.id === candidateId
          ? {
              ...c,
              hrScore: evaluation.overallHrScore,
              hrDecision: evaluation.decision,
              evaluation,
            }
          : c
      )
    );
  };

  const handleNavigate = (tab: TabKey) => {
    setActiveTab(tab);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleUseRoleForScreening = (roleTitle: string) => {
    setPreselectedScreeningRole(roleTitle);
    handleNavigate("screening");
  };

  const handleEvaluateCandidate = (candidateId: string) => {
    setSelectedEvalCandidateId(candidateId);
    handleNavigate("evaluation");
  };

  const handleResetDemoData = () => {
    setRoles(INITIAL_JOB_ROLES);
    setCandidates(INITIAL_CANDIDATES);
    setSelectedEvalCandidateId(INITIAL_CANDIDATES[0].id);
    localStorage.removeItem(STORAGE_KEYS.roles);
    localStorage.removeItem(STORAGE_KEYS.candidates);
  };

  const isInterviewSection = activeTab === "questions" || activeTab === "evaluation";

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 lg:flex">
      {/* Desktop Sidebar Navigation Rail */}
      <aside className="hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0 border-r border-slate-200 bg-white">
        <div className="flex h-16 items-center gap-3 border-b border-slate-100 px-5">
          <BrandEmblem />
          <button
            type="button"
            onClick={() => handleNavigate("home")}
            className="text-left text-sm font-bold tracking-tight text-slate-900 leading-tight cursor-pointer"
          >
            AI Recruitment Assistant
          </button>
        </div>

        <nav aria-label="Primary navigation" className="flex-1 space-y-1 p-3.5">
          {SIDEBAR_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.key;
            return (
              <button
                key={item.key}
                type="button"
                onClick={() => handleNavigate(item.key)}
                className={`flex w-full min-h-[44px] items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium transition-colors cursor-pointer whitespace-nowrap ${
                  active
                    ? "bg-teal-700 text-white shadow-sm"
                    : "text-slate-600 hover:bg-slate-100/80 hover:text-slate-900"
                }`}
              >
                <Icon
                  className={`h-4 w-4 shrink-0 ${active ? "text-teal-100" : "text-slate-400"}`}
                />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="border-t border-slate-100 p-4 space-y-3">
          <div className="rounded-xl bg-slate-50 p-3 text-xs leading-relaxed text-slate-600">
            Human HR professionals hold final authority over all shortlisting and hiring decisions.
          </div>
          <button
            type="button"
            onClick={handleResetDemoData}
            className="flex w-full min-h-[40px] items-center justify-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-slate-600 transition-colors hover:bg-slate-50 hover:text-slate-900 cursor-pointer"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            Reset Sample Data
          </button>
        </div>
      </aside>

      {/* Main Content Shell */}
      <div className="flex-1 lg:pl-64 flex flex-col min-h-screen">
        {/* Mobile Android-style Sticky Top App Bar (56px) */}
        <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b border-slate-200 bg-white/95 px-4 backdrop-blur-md lg:hidden">
          <div className="flex items-center gap-2.5 min-w-0">
            {activeTab !== "home" ? (
              <button
                type="button"
                onClick={() => handleNavigate("home")}
                aria-label="Back to Home"
                className="-ml-2 min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-700 hover:bg-slate-100 cursor-pointer"
              >
                <ChevronLeft className="h-5 w-5" />
              </button>
            ) : (
              <BrandEmblem />
            )}
            <h1 className="truncate text-base font-bold text-slate-900">
              {TAB_TITLES[activeTab]}
            </h1>
          </div>

          <button
            type="button"
            onClick={handleResetDemoData}
            title="Reset sample data"
            aria-label="Reset sample data"
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 hover:text-slate-900 shrink-0 cursor-pointer"
          >
            <RotateCcw className="h-4 w-4" />
          </button>
        </header>

        {/* Desktop Contextual Header */}
        <header className="hidden lg:flex h-16 items-center justify-between border-b border-slate-200 bg-white px-8">
          <div className="flex items-baseline gap-3">
            <h1 className="text-lg font-bold text-slate-900">{TAB_TITLES[activeTab]}</h1>
            <span className="text-xs text-slate-400">·</span>
            <span className="text-xs font-medium text-slate-500">
              {TAB_SUBTITLES[activeTab]}
            </span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-xs text-slate-500 tabular-nums">
              {roles.length} active roles · {candidates.length} candidates
            </span>
            <button
              type="button"
              onClick={() => handleNavigate("screening")}
              className="min-h-[40px] rounded-xl bg-teal-700 px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-teal-800 whitespace-nowrap shrink-0 cursor-pointer"
            >
              Screen Candidate
            </button>
          </div>
        </header>

        {/* Mobile Interview Sub-Switcher when inside Questions or Evaluation */}
        {isInterviewSection && (
          <div className="border-b border-slate-200 bg-white px-4 py-2.5 lg:hidden">
            <div className="grid grid-cols-2 gap-1 rounded-xl bg-slate-100 p-1">
              <button
                type="button"
                onClick={() => handleNavigate("questions")}
                className={`min-h-[40px] rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                  activeTab === "questions"
                    ? "bg-white text-slate-900 shadow-sm"
                    : "text-slate-600"
                }`}
              >
                Interview Questions
              </button>
              <button
                type="button"
                onClick={() => handleNavigate("evaluation")}
                className={`min-h-[40px] rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                  activeTab === "evaluation"
                    ? "bg-white text-slate-900 shadow-sm"
                    : "text-slate-600"
                }`}
              >
                Candidate Evaluation
              </button>
            </div>
          </div>
        )}

        {/* Active Screen Viewport */}
        <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-5 pb-24 sm:px-6 lg:px-8 lg:py-7 lg:pb-10">
          {activeTab === "home" && (
            <HomeView
              roles={roles}
              candidates={candidates}
              onNavigate={handleNavigate}
              onSelectCandidateForEval={handleEvaluateCandidate}
            />
          )}

          {activeTab === "jd" && (
            <JobDescriptionGenerator
              roles={roles}
              onSaveRole={handleSaveRole}
              onUseForScreening={handleUseRoleForScreening}
            />
          )}

          {activeTab === "screening" && (
            <ResumeScreening
              roles={roles}
              preselectedRoleTitle={preselectedScreeningRole}
              onAddToShortlist={handleAddCandidateToShortlist}
              onGoToShortlist={() => handleNavigate("shortlist")}
            />
          )}

          {activeTab === "shortlist" && (
            <CandidateShortlisting
              candidates={candidates}
              roles={roles}
              onUpdateDecision={handleUpdateDecision}
              onEvaluateCandidate={handleEvaluateCandidate}
            />
          )}

          {activeTab === "questions" && (
            <InterviewQuestionsGenerator
              roles={roles}
              onGoToEvaluation={() => handleNavigate("evaluation")}
            />
          )}

          {activeTab === "evaluation" && (
            <CandidateEvaluation
              candidates={candidates}
              selectedCandidateId={selectedEvalCandidateId}
              onSelectCandidateId={setSelectedEvalCandidateId}
              onSaveEvaluation={handleSaveEvaluation}
              onGoToShortlist={() => handleNavigate("shortlist")}
            />
          )}
        </main>
      </div>

      {/* Mobile Fixed Android Material-3 Bottom Navigation Bar (5 Ergonomic Tabs, 64px) */}
      <nav
        aria-label="Mobile navigation"
        className="fixed bottom-0 left-0 right-0 z-40 grid h-16 grid-cols-5 items-center border-t border-slate-200 bg-white/95 backdrop-blur-md pb-safe lg:hidden"
      >
        {[
          { key: "home" as const, label: "Home", icon: Home, active: activeTab === "home" },
          { key: "jd" as const, label: "Job Desc", icon: FileText, active: activeTab === "jd" },
          {
            key: "screening" as const,
            label: "Screen",
            icon: UserCheck,
            active: activeTab === "screening",
          },
          {
            key: "shortlist" as const,
            label: "Shortlist",
            icon: Table2,
            active: activeTab === "shortlist",
          },
          {
            key: (activeTab === "questions" ? "questions" : "evaluation") as TabKey,
            label: "Interview",
            icon: ClipboardCheck,
            active: isInterviewSection,
          },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.label}
              type="button"
              onClick={() => handleNavigate(tab.key)}
              className={`flex min-h-[48px] flex-col items-center justify-center gap-0.5 text-[11px] font-medium cursor-pointer ${
                tab.active ? "text-teal-800 font-semibold" : "text-slate-500"
              }`}
            >
              <span
                className={`flex h-7 w-12 items-center justify-center rounded-full transition-colors ${
                  tab.active ? "bg-teal-100 text-teal-800" : "bg-transparent"
                }`}
              >
                <Icon className="h-4.5 w-4.5" />
              </span>
              <span className="whitespace-nowrap">{tab.label}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}
