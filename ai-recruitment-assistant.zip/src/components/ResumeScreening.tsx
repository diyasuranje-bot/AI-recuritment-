import { useEffect, useState } from "react";
import { AlertCircle, CheckCircle2, Loader2, Plus, UserCheck } from "lucide-react";
import { SAMPLE_SCREENING_PRESETS } from "../data/sampleData";
import type { Candidate, JobRole, ScreeningResult } from "../types/recruitment";

interface ResumeScreeningProps {
  roles: JobRole[];
  preselectedRoleTitle?: string;
  onAddToShortlist: (candidate: Candidate) => void;
  onGoToShortlist: () => void;
}

function ScoreRing({ score }: { score: number }) {
  const clamped = Math.min(Math.max(score, 0), 100);
  const radius = 30;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (clamped / 100) * circumference;
  const strokeColor =
    clamped >= 80 ? "#0f766e" : clamped >= 65 ? "#d97706" : "#dc2626";

  return (
    <div className="relative flex h-20 w-20 shrink-0 items-center justify-center">
      <svg className="h-20 w-20 -rotate-90" viewBox="0 0 72 72" aria-hidden="true">
        <circle
          cx="36"
          cy="36"
          r={radius}
          fill="none"
          stroke="#e2e8f0"
          strokeWidth="6"
        />
        <circle
          cx="36"
          cy="36"
          r={radius}
          fill="none"
          stroke={strokeColor}
          strokeWidth="6"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          className="transition-all duration-500"
        />
      </svg>
      <span className="absolute font-mono text-lg font-bold text-slate-900 tabular-nums">
        {clamped}%
      </span>
    </div>
  );
}

export default function ResumeScreening({
  roles,
  preselectedRoleTitle,
  onAddToShortlist,
  onGoToShortlist,
}: ResumeScreeningProps) {
  const defaultRole =
    roles.find((r) => r.title === preselectedRoleTitle) ?? roles[0];

  const [selectedRoleTitle, setSelectedRoleTitle] = useState(defaultRole?.title ?? "Product Manager");
  const [jobRequirements, setJobRequirements] = useState(
    defaultRole ? defaultRole.requiredSkills.join(", ") : ""
  );

  const [candidateName, setCandidateName] = useState(SAMPLE_SCREENING_PRESETS[0].name);
  const [currentRole, setCurrentRole] = useState(SAMPLE_SCREENING_PRESETS[0].currentRole);
  const [experienceYears, setExperienceYears] = useState(
    String(SAMPLE_SCREENING_PRESETS[0].experienceYears)
  );
  const [education, setEducation] = useState(SAMPLE_SCREENING_PRESETS[0].education);
  const [skills, setSkills] = useState(SAMPLE_SCREENING_PRESETS[0].skills);
  const [resumeSummary, setResumeSummary] = useState(SAMPLE_SCREENING_PRESETS[0].resumeSummary);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<ScreeningResult | null>(null);
  const [addedToTable, setAddedToTable] = useState(false);

  useEffect(() => {
    if (preselectedRoleTitle) {
      const matched = roles.find((r) => r.title === preselectedRoleTitle);
      if (matched) {
        setSelectedRoleTitle(matched.title);
        setJobRequirements(matched.requiredSkills.join(", "));
      }
    }
  }, [preselectedRoleTitle, roles]);

  const handleRoleChange = (title: string) => {
    setSelectedRoleTitle(title);
    const matched = roles.find((r) => r.title === title);
    if (matched) {
      setJobRequirements(matched.requiredSkills.join(", "));
    }
    setResult(null);
    setAddedToTable(false);
  };

  const applySampleCandidate = (index: number) => {
    const sample = SAMPLE_SCREENING_PRESETS[index];
    if (!sample) return;
    setCandidateName(sample.name);
    setCurrentRole(sample.currentRole);
    setExperienceYears(String(sample.experienceYears));
    setEducation(sample.education);
    setSkills(sample.skills);
    setResumeSummary(sample.resumeSummary);
    const matchingRole = roles.find((r) => r.title === sample.suggestedRoleTitle);
    if (matchingRole) {
      setSelectedRoleTitle(matchingRole.title);
      setJobRequirements(matchingRole.requiredSkills.join(", "));
    }
    setResult(null);
    setAddedToTable(false);
    setError(null);
  };

  const handleScreen = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!candidateName.trim() || !resumeSummary.trim()) {
      setError("Candidate name and resume summary are required.");
      return;
    }

    setLoading(true);
    setError(null);
    setAddedToTable(false);

    try {
      const response = await fetch("/api/screen-resume", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          candidateName: candidateName.trim(),
          currentRole: currentRole.trim(),
          experienceYears: Number(experienceYears) || 0,
          education: education.trim(),
          skills: skills.trim(),
          resumeSummary: resumeSummary.trim(),
          jobTitle: selectedRoleTitle,
          jobRequirements: jobRequirements.trim(),
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Unable to screen candidate.");
      }
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to screen candidate.");
    } finally {
      setLoading(false);
    }
  };

  const handleSaveCandidate = () => {
    if (!result) return;
    const slug = candidateName
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, ".");
    const newCandidate: Candidate = {
      id: `cand-${Date.now()}`,
      name: candidateName.trim(),
      email: `${slug || "candidate"}@example.com`,
      currentRole: currentRole.trim() || "Applicant",
      targetRole: selectedRoleTitle,
      experienceYears: Number(experienceYears) || 0,
      education: education.trim() || "Not specified",
      location: "Remote / India",
      skills: skills
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean),
      resumeSummary: resumeSummary.trim(),
      aiMatchScore: result.matchScore,
      hrScore: null,
      hrDecision: "Pending Review",
      aiAdvisoryNote: result.hrAdvisorySummary,
    };

    onAddToShortlist(newCandidate);
    setAddedToTable(true);
  };

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
      {/* Input Form */}
      <section className="lg:col-span-6 rounded-2xl border border-slate-200 bg-white p-5 sm:p-6">
        <div className="space-y-1 border-b border-slate-100 pb-4">
          <h2 className="text-lg font-bold text-slate-900">Resume Screening</h2>
          <p className="text-sm text-slate-600">
            Compare candidate qualifications against a target role. Human HR makes the final
            shortlisting decision.
          </p>
        </div>

        {/* Sample Presets */}
        <div className="mt-4">
          <p className="text-xs font-medium text-slate-500">Load sample candidate profile</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {SAMPLE_SCREENING_PRESETS.map((sample, idx) => (
              <button
                key={sample.label}
                type="button"
                onClick={() => applySampleCandidate(idx)}
                className={`min-h-[40px] rounded-xl border px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  candidateName === sample.name
                    ? "border-teal-700 bg-teal-50 text-teal-800"
                    : "border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100"
                }`}
              >
                {sample.label}
              </button>
            ))}
          </div>
        </div>

        <form onSubmit={handleScreen} className="mt-5 space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="screen-role" className="block text-xs font-medium text-slate-700">
                Target Job Role
              </label>
              <select
                id="screen-role"
                value={selectedRoleTitle}
                onChange={(e) => handleRoleChange(e.target.value)}
                className="mt-1.5 w-full min-h-[44px] rounded-xl border border-slate-300 bg-white px-3.5 text-sm text-slate-900 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/15"
              >
                {roles.map((r) => (
                  <option key={r.id} value={r.title}>
                    {r.title}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="cand-name" className="block text-xs font-medium text-slate-700">
                Candidate Full Name
              </label>
              <input
                id="cand-name"
                type="text"
                value={candidateName}
                onChange={(e) => setCandidateName(e.target.value)}
                className="mt-1.5 w-full min-h-[44px] rounded-xl border border-slate-300 bg-white px-3.5 text-sm text-slate-900 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/15"
                required
              />
            </div>
          </div>

          <div>
            <label htmlFor="role-reqs" className="block text-xs font-medium text-slate-700">
              Role Requirements for Comparison
            </label>
            <textarea
              id="role-reqs"
              rows={2}
              value={jobRequirements}
              onChange={(e) => setJobRequirements(e.target.value)}
              className="mt-1.5 w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/15"
            />
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div className="sm:col-span-1">
              <label htmlFor="cand-exp" className="block text-xs font-medium text-slate-700">
                Experience (Years)
              </label>
              <input
                id="cand-exp"
                type="number"
                step="0.5"
                min="0"
                max="40"
                value={experienceYears}
                onChange={(e) => setExperienceYears(e.target.value)}
                className="mt-1.5 w-full min-h-[44px] rounded-xl border border-slate-300 bg-white px-3.5 font-mono text-sm text-slate-900 tabular-nums focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/15"
              />
            </div>
            <div className="sm:col-span-2">
              <label htmlFor="cand-role" className="block text-xs font-medium text-slate-700">
                Current / Previous Role
              </label>
              <input
                id="cand-role"
                type="text"
                value={currentRole}
                onChange={(e) => setCurrentRole(e.target.value)}
                className="mt-1.5 w-full min-h-[44px] rounded-xl border border-slate-300 bg-white px-3.5 text-sm text-slate-900 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/15"
              />
            </div>
          </div>

          <div>
            <label htmlFor="cand-edu" className="block text-xs font-medium text-slate-700">
              Education
            </label>
            <input
              id="cand-edu"
              type="text"
              value={education}
              onChange={(e) => setEducation(e.target.value)}
              className="mt-1.5 w-full min-h-[44px] rounded-xl border border-slate-300 bg-white px-3.5 text-sm text-slate-900 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/15"
            />
          </div>

          <div>
            <label htmlFor="cand-skills" className="block text-xs font-medium text-slate-700">
              Candidate Skills
            </label>
            <input
              id="cand-skills"
              type="text"
              value={skills}
              onChange={(e) => setSkills(e.target.value)}
              className="mt-1.5 w-full min-h-[44px] rounded-xl border border-slate-300 bg-white px-3.5 text-sm text-slate-900 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/15"
            />
          </div>

          <div>
            <label htmlFor="cand-summary" className="block text-xs font-medium text-slate-700">
              Resume Summary / Experience Highlights
            </label>
            <textarea
              id="cand-summary"
              rows={4}
              value={resumeSummary}
              onChange={(e) => setResumeSummary(e.target.value)}
              className="mt-1.5 w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/15"
              required
            />
          </div>

          {error && (
            <div
              role="alert"
              className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800"
            >
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full min-h-[48px] inline-flex items-center justify-center gap-2 rounded-xl bg-teal-700 px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-teal-800 disabled:opacity-60 cursor-pointer"
          >
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Comparing Against Role Requirements...
              </>
            ) : (
              <>
                <UserCheck className="h-4 w-4" />
                Analyze Candidate Fit
              </>
            )}
          </button>
        </form>
      </section>

      {/* Results Panel */}
      <section className="lg:col-span-6 space-y-5">
        {result ? (
          <div className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6">
            <div className="flex items-center justify-between gap-4 border-b border-slate-100 pb-5">
              <div className="min-w-0">
                <p className="text-xs font-medium text-teal-700">
                  AI Screening Assessment · Advisory Only
                </p>
                <h3 className="mt-0.5 text-xl font-bold text-slate-900 truncate">
                  {candidateName}
                </h3>
                <p className="mt-0.5 text-xs text-slate-500">
                  Target: {selectedRoleTitle} · {experienceYears} yrs exp · {result.advisoryLabel}
                </p>
              </div>

              <ScoreRing score={result.matchScore} />
            </div>

            <div className="mt-5 space-y-5 text-sm">
              <div className="rounded-xl bg-slate-50 p-4 border border-slate-200/70">
                <h4 className="text-xs font-semibold text-slate-900">HR Advisory Summary</h4>
                <p className="mt-1.5 leading-relaxed text-slate-700">{result.hrAdvisorySummary}</p>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="rounded-xl border border-emerald-200/70 bg-emerald-50/40 p-4">
                  <h4 className="flex items-center gap-1.5 text-xs font-semibold text-emerald-800">
                    <CheckCircle2 className="h-4 w-4 shrink-0" />
                    Matched Requirements
                  </h4>
                  <ul className="mt-2.5 space-y-1.5 text-xs leading-relaxed text-slate-700">
                    {result.matchedSkills.length > 0 ? (
                      result.matchedSkills.map((skill, i) => <li key={i}>· {skill}</li>)
                    ) : (
                      <li className="text-slate-500">None explicitly matched</li>
                    )}
                  </ul>
                </div>

                <div className="rounded-xl border border-amber-200/70 bg-amber-50/40 p-4">
                  <h4 className="flex items-center gap-1.5 text-xs font-semibold text-amber-800">
                    <AlertCircle className="h-4 w-4 shrink-0" />
                    Missing / Unverified Skills
                  </h4>
                  <ul className="mt-2.5 space-y-1.5 text-xs leading-relaxed text-slate-700">
                    {result.missingSkills.length > 0 ? (
                      result.missingSkills.map((skill, i) => <li key={i}>· {skill}</li>)
                    ) : (
                      <li className="text-slate-500">No major gaps detected</li>
                    )}
                  </ul>
                </div>
              </div>

              <div>
                <h4 className="text-xs font-semibold text-slate-900">Key Strengths</h4>
                <ul className="mt-2 list-disc space-y-1.5 pl-5 text-slate-600">
                  {result.strengths.map((item, i) => (
                    <li key={i}>{item}</li>
                  ))}
                </ul>
              </div>

              <div>
                <h4 className="text-xs font-semibold text-slate-900">
                  Suggested Questions for Human Interviewer
                </h4>
                <ul className="mt-2 list-disc space-y-1.5 pl-5 text-slate-600">
                  {result.interviewProbes.map((item, i) => (
                    <li key={i}>{item}</li>
                  ))}
                </ul>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-4">
                {addedToTable ? (
                  <button
                    type="button"
                    onClick={onGoToShortlist}
                    className="min-h-[44px] inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-xs font-semibold text-white hover:bg-slate-800 cursor-pointer"
                  >
                    View Candidate in Shortlist Table &rarr;
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={handleSaveCandidate}
                    className="min-h-[44px] inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-xs font-semibold text-white hover:bg-slate-800 cursor-pointer"
                  >
                    <Plus className="h-4 w-4" />
                    Add to Shortlist Table
                  </button>
                )}
                <span className="text-xs text-slate-500">
                  Initial status: Pending Human HR Review
                </span>
              </div>
            </div>
          </div>
        ) : (
          <div className="rounded-2xl border border-slate-200 bg-white p-6 text-center sm:p-10">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-teal-50 text-teal-700">
              <UserCheck className="h-6 w-6" />
            </div>
            <h3 className="mt-3 text-base font-semibold text-slate-900">
              Screen Resume Against Job Requirements
            </h3>
            <p className="mx-auto mt-1.5 max-w-md text-sm text-slate-500">
              Select a target role and enter candidate details (or pick a sample profile), then tap
              Analyze Candidate Fit to view the match ring and skill breakdown.
            </p>
          </div>
        )}
      </section>
    </div>
  );
}
