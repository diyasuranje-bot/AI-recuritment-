import { useState } from "react";
import { Check, Copy, FileText, Loader2, Plus } from "lucide-react";
import type { JobRole } from "../types/recruitment";

interface JobDescriptionGeneratorProps {
  roles: JobRole[];
  onSaveRole: (role: JobRole) => void;
  onUseForScreening: (roleTitle: string) => void;
}

interface GeneratedJdPayload {
  title: string;
  department: string;
  experienceLevel: string;
  workMode: string;
  summary: string;
  responsibilities: string[];
  requiredSkills: string[];
  preferredQualifications: string[];
}

const ROLE_PRESETS = [
  {
    title: "Data Analyst",
    department: "Business Intelligence",
    experienceLevel: "Mid-Level (2–4 years)",
    workMode: "Hybrid",
    keySkills: "SQL, Python, Power BI / Tableau, A/B Testing, Stakeholder Reporting",
  },
  {
    title: "Digital Marketing Manager",
    department: "Growth & Marketing",
    experienceLevel: "Mid-Senior (4–6 years)",
    workMode: "Hybrid",
    keySkills: "Performance Marketing, SEO/SEM, HubSpot CRM, Funnel Analytics, Budget Ownership",
  },
  {
    title: "Operations Associate",
    department: "Supply Chain & Ops",
    experienceLevel: "Entry-Level (0–2 years)",
    workMode: "On-site",
    keySkills: "Process Mapping, Excel, Vendor Coordination, SLA Tracking, ERP Basics",
  },
];

export default function JobDescriptionGenerator({
  roles,
  onSaveRole,
  onUseForScreening,
}: JobDescriptionGeneratorProps) {
  const [roleTitle, setRoleTitle] = useState("Data Analyst");
  const [department, setDepartment] = useState("Business Intelligence");
  const [experienceLevel, setExperienceLevel] = useState("Mid-Level (2–4 years)");
  const [workMode, setWorkMode] = useState("Hybrid");
  const [keySkills, setKeySkills] = useState(
    "SQL, Python, Power BI / Tableau, A/B Testing, Stakeholder Reporting"
  );
  const [notes, setNotes] = useState("");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [generatedJd, setGeneratedJd] = useState<GeneratedJdPayload | null>(null);
  const [copied, setCopied] = useState(false);
  const [savedNotice, setSavedNotice] = useState(false);

  const applyPreset = (preset: (typeof ROLE_PRESETS)[number]) => {
    setRoleTitle(preset.title);
    setDepartment(preset.department);
    setExperienceLevel(preset.experienceLevel);
    setWorkMode(preset.workMode);
    setKeySkills(preset.keySkills);
    setError(null);
  };

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!roleTitle.trim()) {
      setError("Please enter a job title before generating.");
      return;
    }

    setLoading(true);
    setError(null);
    setSavedNotice(false);

    try {
      const response = await fetch("/api/generate-jd", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          roleTitle,
          department,
          experienceLevel,
          workMode,
          keySkills,
          notes,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Unable to generate job description.");
      }
      setGeneratedJd(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to generate job description.");
    } finally {
      setLoading(false);
    }
  };

  const handleSaveToRoles = () => {
    if (!generatedJd) return;
    const newRole: JobRole = {
      id: `role-${Date.now()}`,
      title: generatedJd.title,
      department: generatedJd.department,
      experienceLevel: generatedJd.experienceLevel,
      workMode: generatedJd.workMode,
      summary: generatedJd.summary,
      responsibilities: generatedJd.responsibilities,
      requiredSkills: generatedJd.requiredSkills,
      preferredQualifications: generatedJd.preferredQualifications,
      createdAt: new Date().toISOString().slice(0, 10),
    };
    onSaveRole(newRole);
    setSavedNotice(true);
  };

  const handleCopy = async () => {
    if (!generatedJd) return;
    const text = [
      `${generatedJd.title} (${generatedJd.department} · ${generatedJd.experienceLevel} · ${generatedJd.workMode})`,
      "",
      "Role Summary:",
      generatedJd.summary,
      "",
      "Key Responsibilities:",
      ...generatedJd.responsibilities.map((item) => `- ${item}`),
      "",
      "Required Skills:",
      ...generatedJd.requiredSkills.map((item) => `- ${item}`),
      "",
      "Preferred Qualifications:",
      ...generatedJd.preferredQualifications.map((item) => `- ${item}`),
    ].join("\n");

    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
      {/* Left Form Panel */}
      <section className="lg:col-span-5 rounded-2xl border border-slate-200 bg-white p-5 sm:p-6 self-start">
        <div className="space-y-1 border-b border-slate-100 pb-4">
          <h2 className="text-lg font-bold text-slate-900">Job Description Generator</h2>
          <p className="text-sm text-slate-600">
            Specify role parameters to draft an inclusive, structured job posting.
          </p>
        </div>

        {/* Quick Presets */}
        <div className="mt-4">
          <p className="text-xs font-medium text-slate-500">Quick-fill presets</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {ROLE_PRESETS.map((preset) => (
              <button
                key={preset.title}
                type="button"
                onClick={() => applyPreset(preset)}
                className={`min-h-[40px] rounded-xl border px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  roleTitle === preset.title
                    ? "border-teal-700 bg-teal-50 text-teal-800"
                    : "border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100"
                }`}
              >
                {preset.title}
              </button>
            ))}
          </div>
        </div>

        <form onSubmit={handleGenerate} className="mt-5 space-y-4">
          <div>
            <label htmlFor="jd-title" className="block text-xs font-medium text-slate-700">
              Job Title
            </label>
            <input
              id="jd-title"
              type="text"
              value={roleTitle}
              onChange={(e) => setRoleTitle(e.target.value)}
              placeholder="e.g., Product Manager"
              className="mt-1.5 w-full min-h-[44px] rounded-xl border border-slate-300 bg-white px-3.5 text-sm text-slate-900 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/15"
              required
            />
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="jd-dept" className="block text-xs font-medium text-slate-700">
                Department
              </label>
              <input
                id="jd-dept"
                type="text"
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                placeholder="e.g., Engineering"
                className="mt-1.5 w-full min-h-[44px] rounded-xl border border-slate-300 bg-white px-3.5 text-sm text-slate-900 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/15"
              />
            </div>

            <div>
              <label htmlFor="jd-mode" className="block text-xs font-medium text-slate-700">
                Work Mode
              </label>
              <select
                id="jd-mode"
                value={workMode}
                onChange={(e) => setWorkMode(e.target.value)}
                className="mt-1.5 w-full min-h-[44px] rounded-xl border border-slate-300 bg-white px-3.5 text-sm text-slate-900 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/15"
              >
                <option value="Hybrid">Hybrid</option>
                <option value="On-site">On-site</option>
                <option value="Remote">Remote</option>
              </select>
            </div>
          </div>

          <div>
            <label htmlFor="jd-exp" className="block text-xs font-medium text-slate-700">
              Experience Level
            </label>
            <select
              id="jd-exp"
              value={experienceLevel}
              onChange={(e) => setExperienceLevel(e.target.value)}
              className="mt-1.5 w-full min-h-[44px] rounded-xl border border-slate-300 bg-white px-3.5 text-sm text-slate-900 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/15"
            >
              <option value="Entry-Level (0–2 years)">Entry-Level (0–2 years)</option>
              <option value="Mid-Level (2–4 years)">Mid-Level (2–4 years)</option>
              <option value="Mid-Senior (4–6 years)">Mid-Senior (4–6 years)</option>
              <option value="Senior / Lead (7+ years)">Senior / Lead (7+ years)</option>
            </select>
          </div>

          <div>
            <label htmlFor="jd-skills" className="block text-xs font-medium text-slate-700">
              Key Skills (comma-separated)
            </label>
            <textarea
              id="jd-skills"
              rows={2}
              value={keySkills}
              onChange={(e) => setKeySkills(e.target.value)}
              placeholder="e.g., SQL, Financial Modeling, Stakeholder Communication"
              className="mt-1.5 w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/15"
            />
          </div>

          <div>
            <label htmlFor="jd-notes" className="block text-xs font-medium text-slate-700">
              Hiring Manager Notes (optional)
            </label>
            <textarea
              id="jd-notes"
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g., Team of 6 analysts supporting retail banking expansion"
              className="mt-1.5 w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/15"
            />
          </div>

          {error && (
            <div
              role="alert"
              className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800"
            >
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full min-h-[48px] inline-flex items-center justify-center gap-2 rounded-xl bg-teal-700 px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-teal-800 disabled:opacity-60 cursor-pointer"
          >
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Drafting Job Description...
              </>
            ) : (
              <>
                <FileText className="h-4 w-4" />
                Generate Job Description
              </>
            )}
          </button>
        </form>
      </section>

      {/* Right Preview & Saved Roles */}
      <section className="lg:col-span-7 space-y-6">
        {generatedJd ? (
          <div className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6">
            <div className="flex flex-col gap-3 border-b border-slate-100 pb-4 sm:flex-row sm:items-start sm:justify-between">
              <div>
                <p className="text-xs font-medium text-teal-700">Generated Role Specification</p>
                <h3 className="mt-0.5 text-xl font-bold text-slate-900">{generatedJd.title}</h3>
                <p className="mt-1 text-xs text-slate-500">
                  {generatedJd.department} · {generatedJd.experienceLevel} · {generatedJd.workMode}
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={handleCopy}
                  className="min-h-[40px] inline-flex items-center gap-1.5 rounded-xl border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  {copied ? (
                    <Check className="h-3.5 w-3.5 text-teal-700" />
                  ) : (
                    <Copy className="h-3.5 w-3.5" />
                  )}
                  {copied ? "Copied" : "Copy Text"}
                </button>
                <button
                  type="button"
                  onClick={handleSaveToRoles}
                  disabled={savedNotice}
                  className="min-h-[40px] inline-flex items-center gap-1.5 rounded-xl bg-slate-900 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-slate-800 disabled:bg-teal-700 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  {savedNotice ? (
                    <>
                      <Check className="h-3.5 w-3.5" />
                      Saved to Active Roles
                    </>
                  ) : (
                    <>
                      <Plus className="h-3.5 w-3.5" />
                      Save Role
                    </>
                  )}
                </button>
              </div>
            </div>

            <div className="mt-5 space-y-5 text-sm text-slate-700">
              <div className="rounded-xl border border-slate-200/70 bg-slate-50 p-4">
                <h4 className="text-xs font-semibold tracking-wide text-slate-900">Role Summary</h4>
                <p className="mt-1.5 leading-relaxed text-slate-700">{generatedJd.summary}</p>
              </div>

              <div>
                <h4 className="text-xs font-semibold tracking-wide text-slate-900">
                  Key Responsibilities
                </h4>
                <ul className="mt-2 list-disc space-y-1.5 pl-5 text-slate-600">
                  {generatedJd.responsibilities.map((item, idx) => (
                    <li key={idx}>{item}</li>
                  ))}
                </ul>
              </div>

              <div>
                <h4 className="text-xs font-semibold tracking-wide text-slate-900">
                  Required Skills
                </h4>
                <p className="mt-1.5 text-sm leading-relaxed text-slate-700">
                  {generatedJd.requiredSkills.join(" · ")}
                </p>
              </div>

              <div>
                <h4 className="text-xs font-semibold tracking-wide text-slate-900">
                  Preferred Qualifications
                </h4>
                <ul className="mt-2 list-disc space-y-1.5 pl-5 text-slate-600">
                  {generatedJd.preferredQualifications.map((item, idx) => (
                    <li key={idx}>{item}</li>
                  ))}
                </ul>
              </div>

              <div className="border-t border-slate-100 pt-4 flex flex-wrap items-center justify-between gap-3">
                <span className="text-xs text-slate-500">
                  Human HR review recommended before publishing externally.
                </span>
                <button
                  type="button"
                  onClick={() => {
                    if (!savedNotice) handleSaveToRoles();
                    onUseForScreening(generatedJd.title);
                  }}
                  className="min-h-[40px] text-xs font-semibold text-teal-700 hover:underline whitespace-nowrap shrink-0 cursor-pointer"
                >
                  Screen candidates for this role &rarr;
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="rounded-2xl border border-slate-200 bg-white p-6 text-center sm:p-8">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-teal-50 text-teal-700">
              <FileText className="h-6 w-6" />
            </div>
            <h3 className="mt-3 text-base font-semibold text-slate-900">
              Ready to draft a job description
            </h3>
            <p className="mx-auto mt-1.5 max-w-md text-sm text-slate-500">
              Choose a quick-fill preset or enter custom role requirements on the left, then tap
              Generate Job Description.
            </p>
          </div>
        )}

        {/* Active Saved Roles Library */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-sm font-semibold text-slate-900">
              Active Open Roles ({roles.length})
            </h3>
            <span className="text-xs text-slate-500">Available in Screening &amp; Questions</span>
          </div>
          <div className="mt-2 divide-y divide-slate-100">
            {roles.map((role) => (
              <div
                key={role.id}
                className="flex flex-col gap-2 py-3 sm:flex-row sm:items-center sm:justify-between"
              >
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-slate-900">{role.title}</p>
                  <p className="text-xs text-slate-500 truncate">
                    {role.department} · {role.experienceLevel} · {role.workMode}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => onUseForScreening(role.title)}
                  className="min-h-[40px] self-start rounded-xl border border-slate-200 px-3.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap shrink-0 cursor-pointer sm:self-center"
                >
                  Screen Role
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
