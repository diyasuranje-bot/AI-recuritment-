import { useMemo, useState } from "react";
import { ArrowUpDown, ClipboardCheck, Search, X } from "lucide-react";
import type { Candidate, HrDecision, JobRole } from "../types/recruitment";

interface CandidateShortlistingProps {
  candidates: Candidate[];
  roles: JobRole[];
  onUpdateDecision: (candidateId: string, decision: HrDecision) => void;
  onEvaluateCandidate: (candidateId: string) => void;
}

const DECISION_OPTIONS: HrDecision[] = [
  "Pending Review",
  "Shortlisted",
  "Proceed to Offer",
  "Hold",
  "Not Selected",
];

function getInitials(name: string): string {
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return `${parts[0][0] ?? ""}${parts[parts.length - 1][0] ?? ""}`.toUpperCase();
}

function getDecisionColorClass(decision: HrDecision): string {
  switch (decision) {
    case "Proceed to Offer":
      return "text-emerald-700 font-semibold";
    case "Shortlisted":
      return "text-teal-700 font-semibold";
    case "Hold":
      return "text-amber-700 font-medium";
    case "Not Selected":
      return "text-red-700 font-medium";
    default:
      return "text-slate-600 font-medium";
  }
}

export default function CandidateShortlisting({
  candidates,
  roles,
  onUpdateDecision,
  onEvaluateCandidate,
}: CandidateShortlistingProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState("ALL");
  const [decisionFilter, setDecisionFilter] = useState("ALL");
  const [sortBy, setSortBy] = useState<"ai" | "hr">("ai");
  const [sortAsc, setSortAsc] = useState(false);
  const [selectedCandidate, setSelectedCandidate] = useState<Candidate | null>(null);

  const uniqueRoles = useMemo(() => {
    const titles = new Set<string>(roles.map((r) => r.title));
    candidates.forEach((c) => titles.add(c.targetRole));
    return Array.from(titles);
  }, [roles, candidates]);

  const filteredCandidates = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return candidates
      .filter((c) => {
        if (roleFilter !== "ALL" && c.targetRole !== roleFilter) return false;
        if (decisionFilter !== "ALL" && c.hrDecision !== decisionFilter) return false;
        if (q) {
          const matches =
            c.name.toLowerCase().includes(q) ||
            c.targetRole.toLowerCase().includes(q) ||
            c.currentRole.toLowerCase().includes(q) ||
            c.skills.some((s) => s.toLowerCase().includes(q));
          if (!matches) return false;
        }
        return true;
      })
      .sort((a, b) => {
        const valA = sortBy === "ai" ? a.aiMatchScore : (a.hrScore ?? -1);
        const valB = sortBy === "ai" ? b.aiMatchScore : (b.hrScore ?? -1);
        return sortAsc ? valA - valB : valB - valA;
      });
  }, [candidates, searchQuery, roleFilter, decisionFilter, sortBy, sortAsc]);

  const toggleSort = (field: "ai" | "hr") => {
    if (sortBy === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortBy(field);
      setSortAsc(false);
    }
  };

  const quickTabs: Array<{ label: string; value: string }> = [
    { label: `All (${candidates.length})`, value: "ALL" },
    {
      label: `Shortlisted (${
        candidates.filter(
          (c) => c.hrDecision === "Shortlisted" || c.hrDecision === "Proceed to Offer"
        ).length
      })`,
      value: "SHORTLIST_GROUP",
    },
    {
      label: `Pending (${candidates.filter((c) => c.hrDecision === "Pending Review").length})`,
      value: "Pending Review",
    },
  ];

  const displayedCandidates = useMemo(() => {
    if (decisionFilter === "SHORTLIST_GROUP") {
      return filteredCandidates.filter(
        (c) => c.hrDecision === "Shortlisted" || c.hrDecision === "Proceed to Offer"
      );
    }
    return filteredCandidates;
  }, [filteredCandidates, decisionFilter]);

  const actualFiltered = useMemo(() => {
    if (decisionFilter !== "SHORTLIST_GROUP") return displayedCandidates;
    const q = searchQuery.trim().toLowerCase();
    return candidates
      .filter((c) => {
        if (roleFilter !== "ALL" && c.targetRole !== roleFilter) return false;
        if (c.hrDecision !== "Shortlisted" && c.hrDecision !== "Proceed to Offer") return false;
        if (q) {
          return (
            c.name.toLowerCase().includes(q) ||
            c.targetRole.toLowerCase().includes(q) ||
            c.currentRole.toLowerCase().includes(q) ||
            c.skills.some((s) => s.toLowerCase().includes(q))
          );
        }
        return true;
      })
      .sort((a, b) => {
        const valA = sortBy === "ai" ? a.aiMatchScore : (a.hrScore ?? -1);
        const valB = sortBy === "ai" ? b.aiMatchScore : (b.hrScore ?? -1);
        return sortAsc ? valA - valB : valB - valA;
      });
  }, [candidates, displayedCandidates, decisionFilter, roleFilter, searchQuery, sortBy, sortAsc]);

  return (
    <div className="space-y-5">
      {/* Header & Filter Controls */}
      <section className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Candidate Shortlisting</h2>
            <p className="text-sm text-slate-600">
              Compare AI screening scores with human HR interview ratings. Human HR professionals
              set final shortlist decisions.
            </p>
          </div>

          {/* Interactive Segmented Quick Filter */}
          <div className="inline-flex items-center gap-1 rounded-xl bg-slate-100 p-1 self-start sm:self-center">
            {quickTabs.map((tab) => {
              const active = decisionFilter === tab.value;
              return (
                <button
                  key={tab.value}
                  type="button"
                  onClick={() => setDecisionFilter(tab.value)}
                  className={`min-h-[38px] rounded-lg px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    active
                      ? "bg-white text-slate-900 shadow-sm"
                      : "text-slate-600 hover:text-slate-900"
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Search & Filters */}
        <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-12">
          <div className="relative sm:col-span-5">
            <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search name, role, or skill..."
              aria-label="Search candidates"
              className="w-full min-h-[44px] rounded-xl border border-slate-300 bg-white pl-10 pr-3.5 text-sm text-slate-900 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/15"
            />
          </div>

          <div className="sm:col-span-4">
            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              aria-label="Filter by target role"
              className="w-full min-h-[44px] rounded-xl border border-slate-300 bg-white px-3.5 text-sm text-slate-900 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/15"
            >
              <option value="ALL">All Target Roles</option>
              {uniqueRoles.map((role) => (
                <option key={role} value={role}>
                  {role}
                </option>
              ))}
            </select>
          </div>

          <div className="sm:col-span-3">
            <select
              value={decisionFilter === "SHORTLIST_GROUP" ? "ALL" : decisionFilter}
              onChange={(e) => setDecisionFilter(e.target.value)}
              aria-label="Filter by HR decision"
              className="w-full min-h-[44px] rounded-xl border border-slate-300 bg-white px-3.5 text-sm text-slate-900 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/15"
            >
              <option value="ALL">All Decisions</option>
              {DECISION_OPTIONS.map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>
          </div>
        </div>
      </section>

      {/* Desktop Data Table + Mobile Compact Rows */}
      <section className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
        {actualFiltered.length === 0 ? (
          <div className="p-8 text-center">
            <p className="text-sm font-medium text-slate-900">No matching candidates found</p>
            <p className="mt-1 text-xs text-slate-500">
              Try clearing your search or filter selections.
            </p>
            <button
              type="button"
              onClick={() => {
                setSearchQuery("");
                setRoleFilter("ALL");
                setDecisionFilter("ALL");
              }}
              className="mt-4 min-h-[40px] rounded-xl border border-slate-300 px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <>
            {/* Desktop Table */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full border-collapse text-left text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                    <th className="px-5 py-3.5">Candidate</th>
                    <th className="px-4 py-3.5">Target Role</th>
                    <th className="px-4 py-3.5 text-right">Exp</th>
                    <th className="px-4 py-3.5 text-right">
                      <button
                        type="button"
                        onClick={() => toggleSort("ai")}
                        className="inline-flex items-center gap-1 hover:text-slate-900 cursor-pointer whitespace-nowrap"
                      >
                        AI Match
                        <ArrowUpDown className="h-3.5 w-3.5" />
                      </button>
                    </th>
                    <th className="px-4 py-3.5 text-right">
                      <button
                        type="button"
                        onClick={() => toggleSort("hr")}
                        className="inline-flex items-center gap-1 hover:text-slate-900 cursor-pointer whitespace-nowrap"
                      >
                        HR Score
                        <ArrowUpDown className="h-3.5 w-3.5" />
                      </button>
                    </th>
                    <th className="px-4 py-3.5">Human HR Decision</th>
                    <th className="px-5 py-3.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {actualFiltered.map((candidate) => (
                    <tr key={candidate.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-5 py-3.5">
                        <button
                          type="button"
                          onClick={() => setSelectedCandidate(candidate)}
                          className="flex items-center gap-3 text-left group cursor-pointer"
                        >
                          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-slate-50 font-display text-xs font-bold text-slate-700 group-hover:border-teal-600/40 group-hover:bg-teal-50 group-hover:text-teal-800">
                            {getInitials(candidate.name)}
                          </div>
                          <div>
                            <p className="font-semibold text-slate-900 group-hover:text-teal-700">
                              {candidate.name}
                            </p>
                            <p className="text-xs text-slate-500">
                              {candidate.currentRole} · {candidate.location}
                            </p>
                          </div>
                        </button>
                      </td>
                      <td className="px-4 py-3.5 text-slate-700">{candidate.targetRole}</td>
                      <td className="px-4 py-3.5 text-right font-mono text-slate-700 tabular-nums">
                        {candidate.experienceYears}y
                      </td>
                      <td className="px-4 py-3.5 text-right">
                        <div className="inline-flex flex-col items-end gap-1">
                          <span className="font-mono font-semibold text-teal-700 tabular-nums">
                            {candidate.aiMatchScore}%
                          </span>
                          <div className="h-1 w-14 overflow-hidden rounded-full bg-slate-100">
                            <div
                              className="h-full rounded-full bg-teal-600"
                              style={{ width: `${candidate.aiMatchScore}%` }}
                            />
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3.5 text-right font-mono text-slate-800 tabular-nums">
                        {candidate.hrScore !== null ? (
                          <div className="inline-flex flex-col items-end gap-1">
                            <span className="font-semibold">{candidate.hrScore}%</span>
                            <div className="h-1 w-14 overflow-hidden rounded-full bg-slate-100">
                              <div
                                className="h-full rounded-full bg-slate-800"
                                style={{ width: `${candidate.hrScore}%` }}
                              />
                            </div>
                          </div>
                        ) : (
                          <span className="text-slate-400">—</span>
                        )}
                      </td>
                      <td className="px-4 py-3.5">
                        <select
                          aria-label={`Human HR decision for ${candidate.name}`}
                          value={candidate.hrDecision}
                          onChange={(e) =>
                            onUpdateDecision(candidate.id, e.target.value as HrDecision)
                          }
                          className={`min-h-[38px] rounded-xl border border-slate-200 bg-white px-2.5 text-xs focus:border-teal-700 focus:outline-none ${getDecisionColorClass(
                            candidate.hrDecision
                          )}`}
                        >
                          {DECISION_OPTIONS.map((option) => (
                            <option key={option} value={option} className="text-slate-900">
                              {option}
                            </option>
                          ))}
                        </select>
                      </td>
                      <td className="px-5 py-3.5 text-right">
                        <button
                          type="button"
                          onClick={() => onEvaluateCandidate(candidate.id)}
                          className="min-h-[38px] inline-flex items-center gap-1.5 rounded-xl border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-800 hover:bg-slate-50 whitespace-nowrap shrink-0 cursor-pointer"
                        >
                          <ClipboardCheck className="h-3.5 w-3.5 text-teal-700" />
                          Evaluate
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile Card List */}
            <div className="divide-y divide-slate-100 md:hidden">
              <div className="flex items-center justify-between bg-slate-50 px-4 py-2.5 text-xs font-medium text-slate-600">
                <span>Tap candidate for summary</span>
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => toggleSort("ai")}
                    className="inline-flex items-center gap-1 text-slate-700 cursor-pointer"
                  >
                    Sort AI {sortBy === "ai" ? (sortAsc ? "↑" : "↓") : ""}
                  </button>
                  <button
                    type="button"
                    onClick={() => toggleSort("hr")}
                    className="inline-flex items-center gap-1 text-slate-700 cursor-pointer"
                  >
                    Sort HR {sortBy === "hr" ? (sortAsc ? "↑" : "↓") : ""}
                  </button>
                </div>
              </div>
              {actualFiltered.map((candidate) => (
                <div key={candidate.id} className="p-4 space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <button
                      type="button"
                      onClick={() => setSelectedCandidate(candidate)}
                      className="flex items-center gap-3 text-left min-w-0 cursor-pointer"
                    >
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-slate-50 font-display text-xs font-bold text-slate-700">
                        {getInitials(candidate.name)}
                      </div>
                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold text-slate-900">
                          {candidate.name}
                        </p>
                        <p className="truncate text-xs text-slate-500">
                          {candidate.targetRole} · {candidate.experienceYears} yrs exp
                        </p>
                      </div>
                    </button>
                    <div className="text-right shrink-0">
                      <p className="font-mono text-sm font-bold text-teal-700 tabular-nums">
                        AI {candidate.aiMatchScore}%
                      </p>
                      <p className="font-mono text-xs text-slate-600 tabular-nums">
                        HR {candidate.hrScore !== null ? `${candidate.hrScore}%` : "Pending"}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <select
                      aria-label={`Human HR decision for ${candidate.name}`}
                      value={candidate.hrDecision}
                      onChange={(e) =>
                        onUpdateDecision(candidate.id, e.target.value as HrDecision)
                      }
                      className={`flex-1 min-h-[44px] rounded-xl border border-slate-200 bg-slate-50 px-3 text-xs ${getDecisionColorClass(
                        candidate.hrDecision
                      )}`}
                    >
                      {DECISION_OPTIONS.map((option) => (
                        <option key={option} value={option} className="text-slate-900">
                          {option}
                        </option>
                      ))}
                    </select>
                    <button
                      type="button"
                      onClick={() => onEvaluateCandidate(candidate.id)}
                      className="min-h-[44px] inline-flex items-center gap-1.5 rounded-xl bg-slate-900 px-4 py-2 text-xs font-medium text-white whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      Evaluate
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </section>

      {/* Candidate Detail Modal / Bottom Sheet */}
      {selectedCandidate && (
        <div
          className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 backdrop-blur-sm sm:items-center sm:p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="candidate-detail-title"
        >
          <div className="w-full max-w-lg rounded-t-3xl bg-white p-5 sm:rounded-2xl sm:p-6 max-h-[85vh] overflow-y-auto">
            <div className="mx-auto mb-3 h-1.5 w-10 rounded-full bg-slate-200 sm:hidden" />
            <div className="flex items-start justify-between gap-4 border-b border-slate-100 pb-4">
              <div className="flex items-center gap-3">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-teal-50 font-display text-sm font-bold text-teal-800">
                  {getInitials(selectedCandidate.name)}
                </div>
                <div>
                  <h3 id="candidate-detail-title" className="text-lg font-bold text-slate-900">
                    {selectedCandidate.name}
                  </h3>
                  <p className="text-xs text-slate-500">
                    {selectedCandidate.currentRole} · {selectedCandidate.targetRole} ·{" "}
                    {selectedCandidate.experienceYears} yrs
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedCandidate(null)}
                aria-label="Close candidate details"
                className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="mt-4 space-y-4 text-sm">
              <div className="grid grid-cols-2 gap-4 rounded-xl bg-slate-50 p-3.5">
                <div>
                  <p className="text-xs text-slate-500">AI Fit Score</p>
                  <p className="font-mono text-xl font-bold text-teal-700 tabular-nums">
                    {selectedCandidate.aiMatchScore}%
                  </p>
                </div>
                <div>
                  <p className="text-xs text-slate-500">HR Interview Score</p>
                  <p className="font-mono text-xl font-bold text-slate-900 tabular-nums">
                    {selectedCandidate.hrScore !== null ? `${selectedCandidate.hrScore}%` : "Pending"}
                  </p>
                </div>
              </div>

              <div>
                <p className="text-xs font-semibold text-slate-900">Education &amp; Location</p>
                <p className="mt-1 text-slate-600">
                  {selectedCandidate.education} · {selectedCandidate.location}
                </p>
              </div>

              <div>
                <p className="text-xs font-semibold text-slate-900">Key Skills</p>
                <p className="mt-1 text-slate-600">{selectedCandidate.skills.join(" · ")}</p>
              </div>

              <div>
                <p className="text-xs font-semibold text-slate-900">Resume Summary</p>
                <p className="mt-1 leading-relaxed text-slate-600">
                  {selectedCandidate.resumeSummary}
                </p>
              </div>

              <div>
                <p className="text-xs font-semibold text-slate-900">AI Screening Note</p>
                <p className="mt-1 text-slate-600">{selectedCandidate.aiAdvisoryNote}</p>
              </div>

              {selectedCandidate.evaluation && (
                <div className="border-t border-slate-100 pt-3">
                  <p className="text-xs font-semibold text-slate-900">
                    Latest HR Evaluation ({selectedCandidate.evaluation.interviewDate})
                  </p>
                  <p className="mt-1 text-xs text-slate-500">
                    Interviewer: {selectedCandidate.evaluation.interviewerName}
                  </p>
                  <p className="mt-1.5 text-slate-600">
                    Strengths: {selectedCandidate.evaluation.strengths}
                  </p>
                  {selectedCandidate.evaluation.concerns && (
                    <p className="mt-1 text-slate-600">
                      Notes: {selectedCandidate.evaluation.concerns}
                    </p>
                  )}
                </div>
              )}

              <div className="flex items-center justify-end gap-3 border-t border-slate-100 pt-4">
                <button
                  type="button"
                  onClick={() => setSelectedCandidate(null)}
                  className="min-h-[44px] rounded-xl border border-slate-300 px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  Close
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const id = selectedCandidate.id;
                    setSelectedCandidate(null);
                    onEvaluateCandidate(id);
                  }}
                  className="min-h-[44px] rounded-xl bg-teal-700 px-4 py-2 text-xs font-semibold text-white hover:bg-teal-800 cursor-pointer"
                >
                  Open Evaluation Form
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
