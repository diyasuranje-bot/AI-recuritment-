import { useState } from "react";
import { Check, CheckSquare, Copy, HelpCircle, Loader2, Square } from "lucide-react";
import { INITIAL_INTERVIEW_QUESTIONS } from "../data/sampleData";
import type { InterviewQuestion, JobRole } from "../types/recruitment";

interface InterviewQuestionsGeneratorProps {
  roles: JobRole[];
  onGoToEvaluation: () => void;
}

export default function InterviewQuestionsGenerator({
  roles,
  onGoToEvaluation,
}: InterviewQuestionsGeneratorProps) {
  const [selectedRole, setSelectedRole] = useState(roles[0]?.title ?? "Product Manager");
  const [customRole, setCustomRole] = useState("");
  const [experienceLevel, setExperienceLevel] = useState("Mid-Level (3–5 years)");
  const [focusArea, setFocusArea] = useState(
    "Balanced Mix (Technical, Behavioral, Problem Solving)"
  );
  const [count, setCount] = useState(5);

  const [questions, setQuestions] = useState<InterviewQuestion[]>(INITIAL_INTERVIEW_QUESTIONS);
  const [activeGuideTitle, setActiveGuideTitle] = useState("Product Manager · Sample Guide");
  const [checkedIds, setCheckedIds] = useState<Record<string, boolean>>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const effectiveRole = customRole.trim() || selectedRole;

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!effectiveRole) {
      setError("Please select or enter a job role.");
      return;
    }

    setLoading(true);
    setError(null);

    const matchedRoleObj = roles.find((r) => r.title === effectiveRole);
    const roleContext = matchedRoleObj ? matchedRoleObj.requiredSkills.join(", ") : "";

    try {
      const response = await fetch("/api/generate-questions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          jobRole: effectiveRole,
          experienceLevel,
          focusArea,
          count,
          roleContext,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Unable to generate interview questions.");
      }
      setQuestions(data.questions || []);
      setActiveGuideTitle(`${data.role || effectiveRole} · ${focusArea}`);
      setCheckedIds({});
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to generate interview questions.");
    } finally {
      setLoading(false);
    }
  };

  const toggleChecked = (id: string) => {
    setCheckedIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleCopyGuide = async () => {
    const text = [
      `Interview Guide: ${activeGuideTitle}`,
      "",
      ...questions.map(
        (q, idx) =>
          `${idx + 1}. [${q.category}] ${q.question}\n   Look for: ${q.whatToLookFor}`
      ),
    ].join("\n\n");

    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const askedCount = Object.values(checkedIds).filter(Boolean).length;
  const progressPct = questions.length > 0 ? Math.round((askedCount / questions.length) * 100) : 0;

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
      {/* Configuration Panel */}
      <section className="lg:col-span-4 rounded-2xl border border-slate-200 bg-white p-5 sm:p-6 self-start">
        <div className="space-y-1 border-b border-slate-100 pb-4">
          <h2 className="text-lg font-bold text-slate-900">Interview Questions Generator</h2>
          <p className="text-sm text-slate-600">
            Generate structured role-specific questions with interviewer scoring cues.
          </p>
        </div>

        <form onSubmit={handleGenerate} className="mt-5 space-y-4">
          <div>
            <label htmlFor="iq-role" className="block text-xs font-medium text-slate-700">
              Select Saved Role
            </label>
            <select
              id="iq-role"
              value={selectedRole}
              onChange={(e) => {
                setSelectedRole(e.target.value);
                setCustomRole("");
              }}
              className="mt-1.5 w-full min-h-[44px] rounded-xl border border-slate-300 bg-white px-3.5 text-sm text-slate-900 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/15"
            >
              {roles.map((role) => (
                <option key={role.id} value={role.title}>
                  {role.title}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="iq-custom" className="block text-xs font-medium text-slate-700">
              Or Enter Custom Role (optional)
            </label>
            <input
              id="iq-custom"
              type="text"
              value={customRole}
              onChange={(e) => setCustomRole(e.target.value)}
              placeholder="e.g., Supply Chain Manager"
              className="mt-1.5 w-full min-h-[44px] rounded-xl border border-slate-300 bg-white px-3.5 text-sm text-slate-900 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/15"
            />
          </div>

          <div>
            <label htmlFor="iq-exp" className="block text-xs font-medium text-slate-700">
              Candidate Level
            </label>
            <select
              id="iq-exp"
              value={experienceLevel}
              onChange={(e) => setExperienceLevel(e.target.value)}
              className="mt-1.5 w-full min-h-[44px] rounded-xl border border-slate-300 bg-white px-3.5 text-sm text-slate-900 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/15"
            >
              <option value="Entry-Level (0–2 years)">Entry-Level (0–2 years)</option>
              <option value="Mid-Level (3–5 years)">Mid-Level (3–5 years)</option>
              <option value="Senior / Lead (6+ years)">Senior / Lead (6+ years)</option>
            </select>
          </div>

          <div>
            <label htmlFor="iq-focus" className="block text-xs font-medium text-slate-700">
              Interview Focus
            </label>
            <select
              id="iq-focus"
              value={focusArea}
              onChange={(e) => setFocusArea(e.target.value)}
              className="mt-1.5 w-full min-h-[44px] rounded-xl border border-slate-300 bg-white px-3.5 text-sm text-slate-900 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/15"
            >
              <option value="Balanced Mix (Technical, Behavioral, Problem Solving)">
                Balanced Mix
              </option>
              <option value="Technical & Core Domain Skills">Technical &amp; Domain Skills</option>
              <option value="Behavioral & STAR Leadership">Behavioral &amp; Leadership</option>
              <option value="Case Study & Analytical Thinking">
                Case Study &amp; Analytical Thinking
              </option>
            </select>
          </div>

          <div>
            <label htmlFor="iq-count" className="block text-xs font-medium text-slate-700">
              Number of Questions
            </label>
            <div className="mt-1.5 grid grid-cols-3 gap-2">
              {[5, 7, 10].map((num) => (
                <button
                  key={num}
                  type="button"
                  onClick={() => setCount(num)}
                  className={`min-h-[44px] rounded-xl border font-mono text-sm font-medium tabular-nums transition-colors cursor-pointer ${
                    count === num
                      ? "border-teal-700 bg-teal-50 text-teal-800"
                      : "border-slate-200 bg-white text-slate-700 hover:bg-slate-50"
                  }`}
                >
                  {num}
                </button>
              ))}
            </div>
          </div>

          {error && (
            <div
              role="alert"
              className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800"
            >
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full min-h-[48px] inline-flex items-center justify-center gap-2 rounded-xl bg-teal-700 px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-teal-800 disabled:opacity-60 cursor-pointer"
          >
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Generating Questions...
              </>
            ) : (
              <>
                <HelpCircle className="h-4 w-4" />
                Generate Questions
              </>
            )}
          </button>
        </form>
      </section>

      {/* Questions List */}
      <section className="lg:col-span-8 rounded-2xl border border-slate-200 bg-white p-5 sm:p-6">
        <div className="flex flex-col gap-3 border-b border-slate-100 pb-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900">{activeGuideTitle}</h3>
            <p className="text-xs text-slate-500">
              <span className="font-mono font-semibold text-teal-700 tabular-nums">
                {askedCount}/{questions.length}
              </span>{" "}
              questions covered in session
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleCopyGuide}
              className="min-h-[40px] inline-flex items-center gap-1.5 rounded-xl border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap shrink-0 cursor-pointer"
            >
              {copied ? (
                <Check className="h-3.5 w-3.5 text-teal-700" />
              ) : (
                <Copy className="h-3.5 w-3.5" />
              )}
              {copied ? "Copied" : "Copy Guide"}
            </button>
            <button
              type="button"
              onClick={onGoToEvaluation}
              className="min-h-[40px] inline-flex items-center gap-1.5 rounded-xl bg-slate-900 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
            >
              Score Candidate &rarr;
            </button>
          </div>
        </div>

        {/* Session Progress Bar */}
        <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-slate-100">
          <div
            className="h-full rounded-full bg-teal-700 transition-all duration-300"
            style={{ width: `${progressPct}%` }}
          />
        </div>

        <div className="mt-4 divide-y divide-slate-100">
          {questions.map((item, idx) => {
            const isChecked = !!checkedIds[item.id];
            return (
              <div key={item.id} className="py-4 first:pt-2 last:pb-1">
                <div className="flex items-start gap-3">
                  <button
                    type="button"
                    onClick={() => toggleChecked(item.id)}
                    aria-label={`Mark question ${idx + 1} as asked`}
                    className="mt-0.5 min-h-[42px] min-w-[42px] flex items-center justify-center rounded-xl text-slate-400 hover:bg-slate-100 hover:text-teal-700 shrink-0 cursor-pointer"
                  >
                    {isChecked ? (
                      <CheckSquare className="h-5 w-5 text-teal-700" />
                    ) : (
                      <Square className="h-5 w-5" />
                    )}
                  </button>

                  <div className="min-w-0 flex-1 space-y-2">
                    <p className="text-xs font-medium text-teal-700">
                      <span className="font-mono text-slate-400 tabular-nums">
                        {String(idx + 1).padStart(2, "0")}.
                      </span>{" "}
                      {item.category}
                    </p>
                    <p
                      className={`text-sm font-semibold leading-relaxed sm:text-base ${
                        isChecked ? "text-slate-400 line-through" : "text-slate-900"
                      }`}
                    >
                      {item.question}
                    </p>
                    <div className="rounded-xl border border-slate-200/70 bg-slate-50 px-3.5 py-2.5 text-xs leading-relaxed text-slate-600">
                      <span className="font-semibold text-slate-800">What to look for:</span>{" "}
                      {item.whatToLookFor}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
}
