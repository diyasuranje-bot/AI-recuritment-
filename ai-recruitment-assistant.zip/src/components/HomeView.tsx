import {
  ArrowRight,
  CheckCircle2,
  ClipboardCheck,
  Clock,
  FileText,
  HelpCircle,
  ShieldCheck,
  Table2,
  UserCheck,
} from "lucide-react";
import type { Candidate, JobRole, TabKey } from "../types/recruitment";

interface HomeViewProps {
  roles: JobRole[];
  candidates: Candidate[];
  onNavigate: (tab: TabKey) => void;
  onSelectCandidateForEval: (candidateId: string) => void;
}

const WORKFLOW_ITEMS: Array<{
  key: Exclude<TabKey, "home">;
  step: string;
  title: string;
  description: string;
  cta: string;
  icon: typeof FileText;
}> = [
  {
    key: "jd",
    step: "01",
    title: "Job Description Generator",
    description:
      "Draft structured, inclusive role specifications and publish them to your active hiring pipeline.",
    cta: "Draft Role JD",
    icon: FileText,
  },
  {
    key: "screening",
    step: "02",
    title: "Resume Screening",
    description:
      "Compare applicant skills and experience against role requirements with advisory fit scoring.",
    cta: "Screen Applicant",
    icon: UserCheck,
  },
  {
    key: "shortlist",
    step: "03",
    title: "Candidate Shortlisting",
    description:
      "Compare AI match scores with human HR interview scores in one sortable decision table.",
    cta: "Open Shortlist",
    icon: Table2,
  },
  {
    key: "questions",
    step: "04",
    title: "Interview Questions Generator",
    description:
      "Generate role-tailored technical and behavioral questions paired with interviewer rubrics.",
    cta: "Build Guide",
    icon: HelpCircle,
  },
  {
    key: "evaluation",
    step: "05",
    title: "Candidate Evaluation",
    description:
      "Score five core competencies, capture panel notes, and record final human HR decisions.",
    cta: "Score Interview",
    icon: ClipboardCheck,
  },
];

function getInitials(name: string): string {
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return `${parts[0][0] ?? ""}${parts[parts.length - 1][0] ?? ""}`.toUpperCase();
}

export default function HomeView({
  roles,
  candidates,
  onNavigate,
  onSelectCandidateForEval,
}: HomeViewProps) {
  const offerCount = candidates.filter((c) => c.hrDecision === "Proceed to Offer").length;
  const shortlistedCount = candidates.filter((c) => c.hrDecision === "Shortlisted").length;
  const pendingCount = candidates.filter((c) => c.hrDecision === "Pending Review").length;
  const holdOrRejectedCount = candidates.filter(
    (c) => c.hrDecision === "Hold" || c.hrDecision === "Not Selected"
  ).length;
  const evaluatedCount = candidates.filter((c) => c.hrScore !== null).length;

  const total = Math.max(candidates.length, 1);

  return (
    <div className="space-y-6">
      {/* Executive Welcome Hero */}
      <section className="overflow-hidden rounded-2xl border border-slate-800 bg-gradient-to-br from-slate-900 via-slate-900 to-teal-950 p-5 text-white shadow-sm sm:p-7">
        <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
          <div className="max-w-2xl space-y-2.5">
            <p className="text-xs font-medium tracking-wide text-teal-300">
              Talent Acquisition Command · Human-Led Hiring
            </p>
            <h2 className="text-2xl font-bold tracking-tight text-white sm:text-3xl text-balance">
              Hire faster with structured clarity, while HR keeps the final say.
            </h2>
            <p className="text-sm leading-relaxed text-slate-300 sm:text-base">
              Draft role specifications, compare resumes against job criteria, prepare interview
              guides, and score candidate panels in one cohesive mobile-ready workspace.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => onNavigate("screening")}
              className="min-h-[46px] inline-flex items-center gap-2 rounded-xl bg-teal-600 px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-teal-500 active:scale-[0.98] whitespace-nowrap shrink-0 cursor-pointer"
            >
              Screen a Candidate
              <ArrowRight className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={() => onNavigate("jd")}
              className="min-h-[46px] inline-flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-800/80 px-4 py-2.5 text-sm font-medium text-slate-100 transition-colors hover:bg-slate-800 active:scale-[0.98] whitespace-nowrap shrink-0 cursor-pointer"
            >
              Draft Job Description
            </button>
          </div>
        </div>

        {/* 4-Column KPI Strip */}
        <div className="mt-6 grid grid-cols-2 gap-4 border-t border-slate-800 pt-5 sm:grid-cols-4">
          <div>
            <p className="text-xs text-slate-400">Active Open Roles</p>
            <p className="mt-1 font-mono text-2xl font-semibold text-white tabular-nums">
              {roles.length}
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-400">Candidate Pool</p>
            <p className="mt-1 font-mono text-2xl font-semibold text-white tabular-nums">
              {candidates.length}
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-400">Shortlisted &amp; Offers</p>
            <p className="mt-1 font-mono text-2xl font-semibold text-teal-300 tabular-nums">
              {shortlistedCount + offerCount}
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-400">HR Evaluations Done</p>
            <p className="mt-1 font-mono text-2xl font-semibold text-white tabular-nums">
              {evaluatedCount}
              <span className="ml-1.5 font-sans text-xs font-normal text-slate-400">
                / {candidates.length}
              </span>
            </p>
          </div>
        </div>
      </section>

      {/* Live Pipeline Stage Overview */}
      <section className="rounded-2xl border border-slate-200 bg-white p-5">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">Hiring Pipeline Breakdown</h3>
            <p className="text-xs text-slate-500">
              Live distribution across human HR decision stages
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate("shortlist")}
            className="self-start text-xs font-semibold text-teal-700 hover:underline whitespace-nowrap cursor-pointer sm:self-center"
          >
            Manage pipeline in Shortlist Table &rarr;
          </button>
        </div>

        {/* Proportional Stage Bar */}
        <div className="mt-3.5 flex h-2.5 w-full overflow-hidden rounded-full bg-slate-100">
          {offerCount > 0 && (
            <div
              className="bg-emerald-600 transition-all duration-300"
              style={{ width: `${(offerCount / total) * 100}%` }}
              title={`Proceed to Offer: ${offerCount}`}
            />
          )}
          {shortlistedCount > 0 && (
            <div
              className="bg-teal-600 transition-all duration-300"
              style={{ width: `${(shortlistedCount / total) * 100}%` }}
              title={`Shortlisted: ${shortlistedCount}`}
            />
          )}
          {pendingCount > 0 && (
            <div
              className="bg-amber-500 transition-all duration-300"
              style={{ width: `${(pendingCount / total) * 100}%` }}
              title={`Pending Review: ${pendingCount}`}
            />
          )}
          {holdOrRejectedCount > 0 && (
            <div
              className="bg-slate-300 transition-all duration-300"
              style={{ width: `${(holdOrRejectedCount / total) * 100}%` }}
              title={`Hold / Not Selected: ${holdOrRejectedCount}`}
            />
          )}
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-slate-600">
          <span className="inline-flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-sm bg-emerald-600" aria-hidden="true" />
            Proceed to Offer:{" "}
            <strong className="font-mono text-slate-900 tabular-nums">{offerCount}</strong>
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-sm bg-teal-600" aria-hidden="true" />
            Shortlisted:{" "}
            <strong className="font-mono text-slate-900 tabular-nums">{shortlistedCount}</strong>
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-sm bg-amber-500" aria-hidden="true" />
            Pending Review:{" "}
            <strong className="font-mono text-slate-900 tabular-nums">{pendingCount}</strong>
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-sm bg-slate-300" aria-hidden="true" />
            Hold / Not Selected:{" "}
            <strong className="font-mono text-slate-900 tabular-nums">
              {holdOrRejectedCount}
            </strong>
          </span>
        </div>
      </section>

      {/* Main Content Split: 5 Recruitment Modules + Recent Pipeline */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Recruitment Modules Grid */}
        <section className="lg:col-span-7 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-semibold text-slate-900">Recruitment Workspace</h3>
            <span className="text-xs text-slate-500">5 core HR modules</span>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {WORKFLOW_ITEMS.map((item, idx) => {
              const Icon = item.icon;
              const isSpanFull = idx === WORKFLOW_ITEMS.length - 1;
              return (
                <button
                  key={item.key}
                  type="button"
                  onClick={() => onNavigate(item.key)}
                  className={`group flex flex-col justify-between rounded-2xl border border-slate-200 bg-white p-4 text-left transition-all duration-150 hover:border-teal-600/50 hover:shadow-sm active:scale-[0.99] cursor-pointer min-h-[136px] ${
                    isSpanFull ? "sm:col-span-2" : ""
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-teal-50 text-teal-700 transition-colors group-hover:bg-teal-700 group-hover:text-white">
                      <Icon className="h-5 w-5" />
                    </div>
                    <span className="font-mono text-xs font-medium text-slate-400 tabular-nums">
                      {item.step}
                    </span>
                  </div>

                  <div className="mt-3 space-y-1">
                    <h4 className="text-sm font-semibold text-slate-900 group-hover:text-teal-800">
                      {item.title}
                    </h4>
                    <p className="text-xs leading-relaxed text-slate-600">{item.description}</p>
                  </div>

                  <div className="mt-3 flex items-center gap-1 text-xs font-semibold text-teal-700">
                    <span>{item.cta}</span>
                    <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" />
                  </div>
                </button>
              );
            })}
          </div>
        </section>

        {/* Right Column: Recent Candidates & Governance */}
        <aside className="lg:col-span-5 space-y-5">
          <div className="rounded-2xl border border-slate-200 bg-white p-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-base font-semibold text-slate-900">Recent Candidates</h3>
                <p className="text-xs text-slate-500">Latest profiles in active review</p>
              </div>
              <button
                type="button"
                onClick={() => onNavigate("shortlist")}
                className="min-h-[40px] px-2 text-xs font-semibold text-teal-700 hover:underline whitespace-nowrap shrink-0 cursor-pointer"
              >
                View all {candidates.length}
              </button>
            </div>

            <div className="mt-2 divide-y divide-slate-100">
              {candidates.slice(0, 4).map((candidate) => (
                <div
                  key={candidate.id}
                  className="flex items-center justify-between gap-3 py-3 first:pt-2 last:pb-1"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-slate-50 font-display text-xs font-bold text-slate-700">
                      {getInitials(candidate.name)}
                    </div>
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold text-slate-900">
                        {candidate.name}
                      </p>
                      <p className="truncate text-xs text-slate-500">
                        {candidate.targetRole} · AI{" "}
                        <span className="font-mono font-semibold text-teal-700 tabular-nums">
                          {candidate.aiMatchScore}%
                        </span>
                      </p>
                      <p className="mt-0.5 flex items-center gap-1 text-[11px] font-medium text-slate-600">
                        {candidate.hrDecision === "Pending Review" ? (
                          <Clock className="h-3 w-3 text-amber-600 shrink-0" />
                        ) : (
                          <CheckCircle2 className="h-3 w-3 text-teal-700 shrink-0" />
                        )}
                        <span>{candidate.hrDecision}</span>
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => onSelectCandidateForEval(candidate.id)}
                    className="min-h-[40px] rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-800 transition-colors hover:border-slate-300 hover:bg-slate-50 whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    Evaluate
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-5">
            <div className="flex items-start gap-3.5">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-slate-900 text-teal-400">
                <ShieldCheck className="h-5 w-5" />
              </div>
              <div className="space-y-1">
                <h3 className="text-sm font-semibold text-slate-900">
                  Human-First Decision Standard
                </h3>
                <p className="text-xs leading-relaxed text-slate-600">
                  AI capabilities assist HR teams with drafting, skill comparison, and question
                  prep. Final shortlisting, interview scoring, and offer approvals remain 100%
                  human-led.
                </p>
              </div>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
