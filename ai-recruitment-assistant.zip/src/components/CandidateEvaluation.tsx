import { useEffect, useState } from "react";
import { CheckCircle2, ClipboardCheck, ShieldCheck } from "lucide-react";
import type { Candidate, CandidateEvaluationRecord, HrDecision } from "../types/recruitment";

interface CandidateEvaluationProps {
  candidates: Candidate[];
  selectedCandidateId: string;
  onSelectCandidateId: (id: string) => void;
  onSaveEvaluation: (candidateId: string, evaluation: CandidateEvaluationRecord) => void;
  onGoToShortlist: () => void;
}

const COMPETENCIES: Array<{
  key: keyof CandidateEvaluationRecord["ratings"];
  label: string;
  helper: string;
}> = [
  {
    key: "roleCompetence",
    label: "Technical & Role Competence",
    helper: "Depth of job-specific skills and practical execution.",
  },
  {
    key: "communication",
    label: "Communication Clarity",
    helper: "Structured answers, active listening, and stakeholder polish.",
  },
  {
    key: "problemSolving",
    label: "Problem Solving & Analytical Thinking",
    helper: "Ability to diagnose ambiguity and propose logical trade-offs.",
  },
  {
    key: "cultureFit",
    label: "Culture & Team Alignment",
    helper: "Collaboration habits, ethics, and adaptability.",
  },
  {
    key: "leadership",
    label: "Ownership & Initiative",
    helper: "Accountability for outcomes and proactive follow-through.",
  },
];

const HR_DECISIONS: HrDecision[] = [
  "Shortlisted",
  "Proceed to Offer",
  "Hold",
  "Not Selected",
  "Pending Review",
];

function getInitials(name: string): string {
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return `${parts[0][0] ?? ""}${parts[parts.length - 1][0] ?? ""}`.toUpperCase();
}

export default function CandidateEvaluation({
  candidates,
  selectedCandidateId,
  onSelectCandidateId,
  onSaveEvaluation,
  onGoToShortlist,
}: CandidateEvaluationProps) {
  const activeCandidate =
    candidates.find((c) => c.id === selectedCandidateId) ?? candidates[0];

  const [interviewerName, setInterviewerName] = useState(
    activeCandidate?.evaluation?.interviewerName ?? "Meera Kulkarni (HR Lead)"
  );
  const [interviewDate, setInterviewDate] = useState(
    activeCandidate?.evaluation?.interviewDate ?? new Date().toISOString().slice(0, 10)
  );
  const [ratings, setRatings] = useState<CandidateEvaluationRecord["ratings"]>(
    activeCandidate?.evaluation?.ratings ?? {
      roleCompetence: 4,
      communication: 4,
      problemSolving: 4,
      cultureFit: 4,
      leadership: 4,
    }
  );
  const [strengths, setStrengths] = useState(activeCandidate?.evaluation?.strengths ?? "");
  const [concerns, setConcerns] = useState(activeCandidate?.evaluation?.concerns ?? "");
  const [decision, setDecision] = useState<HrDecision>(
    activeCandidate?.evaluation?.decision ??
      (activeCandidate?.hrDecision && activeCandidate.hrDecision !== "Pending Review"
        ? activeCandidate.hrDecision
        : "Shortlisted")
  );
  const [savedBanner, setSavedBanner] = useState(false);

  useEffect(() => {
    if (!activeCandidate) return;
    setInterviewerName(
      activeCandidate.evaluation?.interviewerName ?? "Meera Kulkarni (HR Lead)"
    );
    setInterviewDate(
      activeCandidate.evaluation?.interviewDate ?? new Date().toISOString().slice(0, 10)
    );
    setRatings(
      activeCandidate.evaluation?.ratings ?? {
        roleCompetence: 4,
        communication: 4,
        problemSolving: 4,
        cultureFit: 4,
        leadership: 4,
      }
    );
    setStrengths(activeCandidate.evaluation?.strengths ?? "");
    setConcerns(activeCandidate.evaluation?.concerns ?? "");
    setDecision(
      activeCandidate.evaluation?.decision ??
        (activeCandidate.hrDecision !== "Pending Review"
          ? activeCandidate.hrDecision
          : "Shortlisted")
    );
    setSavedBanner(false);
  }, [activeCandidate?.id]);

  if (!activeCandidate) {
    return (
      <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center">
        <p className="text-sm text-slate-600">No candidates available to evaluate.</p>
      </div>
    );
  }

  const totalPoints =
    ratings.roleCompetence +
    ratings.communication +
    ratings.problemSolving +
    ratings.cultureFit +
    ratings.leadership;
  const overallHrScore = Math.round((totalPoints / 25) * 100);

  const handleRatingChange = (
    key: keyof CandidateEvaluationRecord["ratings"],
    score: number
  ) => {
    setRatings((prev) => ({ ...prev, [key]: score }));
    setSavedBanner(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const record: CandidateEvaluationRecord = {
      interviewerName: interviewerName.trim() || "HR Reviewer",
      interviewDate,
      ratings,
      overallHrScore,
      strengths: strengths.trim() || "Completed structured interview evaluation.",
      concerns: concerns.trim(),
      decision,
      submittedAt: new Date().toISOString().slice(0, 10),
    };
    onSaveEvaluation(activeCandidate.id, record);
    setSavedBanner(true);
  };

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
      {/* Left Evaluation Form */}
      <section className="lg:col-span-8 rounded-2xl border border-slate-200 bg-white p-5 sm:p-6">
        <div className="flex flex-col gap-2 border-b border-slate-100 pb-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Candidate Evaluation Form</h2>
            <p className="text-sm text-slate-600">
              Record structured interview ratings and enter the final human HR decision.
            </p>
          </div>
          <div className="rounded-xl bg-teal-50 px-4 py-2 text-left sm:text-right shrink-0">
            <p className="text-[11px] font-medium text-teal-800">Calculated HR Score</p>
            <p className="font-mono text-2xl font-bold text-teal-700 tabular-nums">
              {overallHrScore}%
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="mt-5 space-y-5">
          {/* Candidate & Interviewer Metadata */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div>
              <label htmlFor="eval-cand" className="block text-xs font-medium text-slate-700">
                Candidate
              </label>
              <select
                id="eval-cand"
                value={activeCandidate.id}
                onChange={(e) => onSelectCandidateId(e.target.value)}
                className="mt-1.5 w-full min-h-[44px] rounded-xl border border-slate-300 bg-white px-3.5 text-sm text-slate-900 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/15"
              >
                {candidates.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.targetRole})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="eval-interviewer" className="block text-xs font-medium text-slate-700">
                HR Interviewer
              </label>
              <input
                id="eval-interviewer"
                type="text"
                value={interviewerName}
                onChange={(e) => setInterviewerName(e.target.value)}
                className="mt-1.5 w-full min-h-[44px] rounded-xl border border-slate-300 bg-white px-3.5 text-sm text-slate-900 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/15"
                required
              />
            </div>

            <div>
              <label htmlFor="eval-date" className="block text-xs font-medium text-slate-700">
                Interview Date
              </label>
              <input
                id="eval-date"
                type="date"
                value={interviewDate}
                onChange={(e) => setInterviewDate(e.target.value)}
                className="mt-1.5 w-full min-h-[44px] rounded-xl border border-slate-300 bg-white px-3.5 font-mono text-sm text-slate-900 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/15"
                required
              />
            </div>
          </div>

          {/* 5 Competency Ratings (1 to 5 scale) */}
          <div className="space-y-3 border-t border-slate-100 pt-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-slate-900">
                Competency Ratings (1 = Low · 5 = Exceptional)
              </h3>
              <span className="font-mono text-xs text-slate-500 tabular-nums">
                {totalPoints} / 25 pts
              </span>
            </div>

            <div className="divide-y divide-slate-100 rounded-xl border border-slate-200">
              {COMPETENCIES.map((comp) => (
                <div
                  key={comp.key}
                  className="flex flex-col gap-3 p-3.5 sm:flex-row sm:items-center sm:justify-between"
                >
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-slate-900">{comp.label}</p>
                    <p className="text-xs text-slate-500">{comp.helper}</p>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0" role="group" aria-label={comp.label}>
                    {[1, 2, 3, 4, 5].map((score) => {
                      const active = ratings[comp.key] === score;
                      return (
                        <button
                          key={score}
                          type="button"
                          onClick={() => handleRatingChange(comp.key, score)}
                          className={`h-11 w-11 rounded-xl border font-mono text-sm font-semibold tabular-nums transition-colors cursor-pointer ${
                            active
                              ? "border-teal-700 bg-teal-700 text-white shadow-sm"
                              : "border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100"
                          }`}
                        >
                          {score}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Qualitative Notes */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="eval-strengths" className="block text-xs font-medium text-slate-700">
                Observed Strengths
              </label>
              <textarea
                id="eval-strengths"
                rows={3}
                value={strengths}
                onChange={(e) => setStrengths(e.target.value)}
                placeholder="Key examples, domain depth, communication highlights..."
                className="mt-1.5 w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/15"
              />
            </div>

            <div>
              <label htmlFor="eval-concerns" className="block text-xs font-medium text-slate-700">
                Risks / Follow-up Areas
              </label>
              <textarea
                id="eval-concerns"
                rows={3}
                value={concerns}
                onChange={(e) => setConcerns(e.target.value)}
                placeholder="Any skill gaps or topics for final panel verification..."
                className="mt-1.5 w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/15"
              />
            </div>
          </div>

          {/* Final Human HR Decision */}
          <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
            <label htmlFor="eval-decision" className="block text-xs font-semibold text-slate-900">
              Final Human HR Hiring Decision
            </label>
            <p className="mt-0.5 text-xs text-slate-600">
              This decision updates the Candidate Shortlisting table immediately.
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              {HR_DECISIONS.map((option) => (
                <button
                  key={option}
                  type="button"
                  onClick={() => {
                    setDecision(option);
                    setSavedBanner(false);
                  }}
                  className={`min-h-[42px] rounded-xl border px-3.5 py-2 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    decision === option
                      ? "border-slate-900 bg-slate-900 text-white"
                      : "border-slate-300 bg-white text-slate-700 hover:bg-slate-100"
                  }`}
                >
                  {option}
                </button>
              ))}
            </div>
          </div>

          {savedBanner && (
            <div
              role="status"
              className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-900"
            >
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-700 shrink-0" />
                <span>
                  Evaluation saved for <strong>{activeCandidate.name}</strong> ({overallHrScore}% ·{" "}
                  {decision}).
                </span>
              </div>
              <button
                type="button"
                onClick={onGoToShortlist}
                className="text-xs font-semibold text-emerald-800 hover:underline whitespace-nowrap cursor-pointer"
              >
                View Shortlist Table &rarr;
              </button>
            </div>
          )}

          <button
            type="submit"
            className="w-full min-h-[48px] inline-flex items-center justify-center gap-2 rounded-xl bg-teal-700 px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-teal-800 cursor-pointer"
          >
            <ClipboardCheck className="h-4 w-4" />
            Save HR Evaluation &amp; Decision
          </button>
        </form>
      </section>

      {/* Right Context Sidebar */}
      <aside className="lg:col-span-4 space-y-5">
        <div className="rounded-2xl border border-slate-200 bg-white p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-teal-50 font-display text-sm font-bold text-teal-800">
              {getInitials(activeCandidate.name)}
            </div>
            <div className="min-w-0">
              <p className="text-[11px] font-medium text-slate-500">Selected Candidate</p>
              <h3 className="truncate text-base font-bold text-slate-900">
                {activeCandidate.name}
              </h3>
              <p className="truncate text-xs text-slate-500">
                {activeCandidate.currentRole} · {activeCandidate.targetRole}
              </p>
            </div>
          </div>

          <div className="mt-4 grid grid-cols-2 gap-3 border-y border-slate-100 py-3">
            <div>
              <p className="text-xs text-slate-500">AI Screening</p>
              <p className="font-mono text-lg font-bold text-teal-700 tabular-nums">
                {activeCandidate.aiMatchScore}%
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500">Experience</p>
              <p className="font-mono text-lg font-bold text-slate-900 tabular-nums">
                {activeCandidate.experienceYears} yrs
              </p>
            </div>
          </div>

          {/* Live Competency Profile Visualization */}
          <div className="mt-4 space-y-2.5 border-b border-slate-100 pb-4">
            <p className="text-xs font-semibold text-slate-900">Live Competency Profile</p>
            {COMPETENCIES.map((comp) => {
              const val = ratings[comp.key];
              return (
                <div key={comp.key} className="space-y-1">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="truncate text-slate-600">{comp.label}</span>
                    <span className="font-mono font-semibold text-slate-900 tabular-nums">
                      {val}/5
                    </span>
                  </div>
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-100">
                    <div
                      className="h-full rounded-full bg-teal-700 transition-all duration-200"
                      style={{ width: `${(val / 5) * 100}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-4 space-y-3 text-xs leading-relaxed text-slate-600">
            <div>
              <p className="font-semibold text-slate-800">Education</p>
              <p>{activeCandidate.education}</p>
            </div>
            <div>
              <p className="font-semibold text-slate-800">Key Skills</p>
              <p>{activeCandidate.skills.join(" · ")}</p>
            </div>
            <div>
              <p className="font-semibold text-slate-800">AI Advisory Note</p>
              <p>{activeCandidate.aiAdvisoryNote}</p>
            </div>
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5">
          <div className="flex items-start gap-3">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-slate-900 text-teal-400">
              <ShieldCheck className="h-4.5 w-4.5" />
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-semibold text-slate-900">Human Decision Authority</h3>
              <p className="text-xs leading-relaxed text-slate-600">
                AI scores never auto-reject or auto-hire candidates. Your competency ratings and
                qualitative judgment determine the final outcome.
              </p>
            </div>
          </div>
        </div>
      </aside>
    </div>
  );
}
