import "dotenv/config";
import express from "express";
import type { Request, Response } from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 3000;
const MODEL_NAME = "gemini-4-hydrogen";

function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    throw new Error(
      "GEMINI_API_KEY is not configured. Please add your Gemini API key in Settings > Secrets."
    );
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

function handleApiError(res: Response, err: unknown, context: string) {
  const message = err instanceof Error ? err.message : "Unexpected server error";
  console.error(`[${context}]`, err);
  const status = message.includes("GEMINI_API_KEY") ? 503 : 500;
  res.status(status).json({ error: message });
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: "1mb" }));

  // 1. Job Description Generator
  app.post("/api/generate-jd", async (req: Request, res: Response) => {
    try {
      const { roleTitle, department, experienceLevel, workMode, keySkills, notes } = req.body ?? {};
      if (!roleTitle || typeof roleTitle !== "string" || !roleTitle.trim()) {
        res.status(400).json({ error: "Role title is required." });
        return;
      }

      const ai = getGeminiClient();
      const prompt = [
        `Create a clear, modern, bias-free job description for an HR recruitment team.`,
        `Role Title: ${roleTitle.trim()}`,
        `Department: ${department || "General"}`,
        `Experience Level: ${experienceLevel || "Mid-Level (3-5 years)"}`,
        `Work Mode: ${workMode || "Hybrid"}`,
        `Key Skills: ${keySkills || "Domain expertise, collaboration, problem-solving"}`,
        notes ? `Additional Hiring Manager Notes: ${notes}` : "",
        `Keep bullet points concise, actionable, and readable on mobile screens.`,
      ]
        .filter(Boolean)
        .join("\n");

      const response = await ai.models.generateContent({
        model: MODEL_NAME,
        contents: prompt,
        config: {
          systemInstruction:
            "You are a senior HR talent acquisition partner. Produce structured, realistic, inclusive job descriptions tailored for modern organizations.",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              department: { type: Type.STRING },
              experienceLevel: { type: Type.STRING },
              workMode: { type: Type.STRING },
              summary: { type: Type.STRING },
              responsibilities: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              requiredSkills: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              preferredQualifications: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
            },
            required: [
              "title",
              "department",
              "experienceLevel",
              "workMode",
              "summary",
              "responsibilities",
              "requiredSkills",
              "preferredQualifications",
            ],
          },
        },
      });

      const raw = (response.text ?? "{}").trim();
      const parsed = JSON.parse(raw);
      res.json(parsed);
    } catch (err) {
      handleApiError(res, err, "generate-jd");
    }
  });

  // 2. Resume Screening & Role Comparison
  app.post("/api/screen-resume", async (req: Request, res: Response) => {
    try {
      const {
        candidateName,
        currentRole,
        experienceYears,
        education,
        skills,
        resumeSummary,
        jobTitle,
        jobRequirements,
      } = req.body ?? {};

      if (!candidateName || !resumeSummary || !jobTitle) {
        res.status(400).json({
          error: "Candidate name, resume summary, and target job title are required.",
        });
        return;
      }

      const ai = getGeminiClient();
      const prompt = [
        `Compare the candidate profile against the target job requirements and provide an objective screening assessment to assist a human HR reviewer.`,
        ``,
        `TARGET JOB ROLE: ${jobTitle}`,
        `JOB REQUIREMENTS & SKILLS: ${jobRequirements || "Standard role competencies"}`,
        ``,
        `CANDIDATE NAME: ${candidateName}`,
        `CURRENT ROLE: ${currentRole || "Not specified"}`,
        `EXPERIENCE (YEARS): ${experienceYears ?? "Not specified"}`,
        `EDUCATION: ${education || "Not specified"}`,
        `CANDIDATE SKILLS: ${skills || "Not specified"}`,
        `CANDIDATE SUMMARY / EXPERIENCE:`,
        `${resumeSummary}`,
      ].join("\n");

      const response = await ai.models.generateContent({
        model: MODEL_NAME,
        contents: prompt,
        config: {
          systemInstruction:
            "You are an objective HR screening assistant. Score candidate-to-role fit from 0 to 100 based strictly on stated skills and experience. Explicitly emphasize advisory insights for a human HR professional who makes the final hiring decision.",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              matchScore: {
                type: Type.INTEGER,
                description: "Overall fit score between 0 and 100.",
              },
              advisoryLabel: {
                type: Type.STRING,
                description: "One of: Strong Fit, Moderate Fit, Needs Review",
              },
              matchedSkills: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              missingSkills: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              strengths: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              interviewProbes: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              hrAdvisorySummary: {
                type: Type.STRING,
                description: "Concise 2-sentence summary for the human HR decision-maker.",
              },
            },
            required: [
              "matchScore",
              "advisoryLabel",
              "matchedSkills",
              "missingSkills",
              "strengths",
              "interviewProbes",
              "hrAdvisorySummary",
            ],
          },
        },
      });

      const raw = (response.text ?? "{}").trim();
      const parsed = JSON.parse(raw);
      res.json(parsed);
    } catch (err) {
      handleApiError(res, err, "screen-resume");
    }
  });

  // 3. Interview Questions Generator
  app.post("/api/generate-questions", async (req: Request, res: Response) => {
    try {
      const { jobRole, experienceLevel, focusArea, count, roleContext } = req.body ?? {};
      if (!jobRole || typeof jobRole !== "string" || !jobRole.trim()) {
        res.status(400).json({ error: "Job role is required." });
        return;
      }

      const questionCount = Math.min(Math.max(Number(count) || 5, 3), 10);
      const ai = getGeminiClient();

      const prompt = [
        `Generate ${questionCount} structured interview questions for a human HR / hiring panel.`,
        `Target Job Role: ${jobRole.trim()}`,
        `Experience Level: ${experienceLevel || "Mid-Level"}`,
        `Interview Focus: ${focusArea || "Balanced Mix (Technical, Behavioral, Problem Solving)"}`,
        roleContext ? `Role Context / Key Skills: ${roleContext}` : "",
        `For each question, include a clear category and brief guidance on what a strong candidate answer looks like.`,
      ]
        .filter(Boolean)
        .join("\n");

      const response = await ai.models.generateContent({
        model: MODEL_NAME,
        contents: prompt,
        config: {
          systemInstruction:
            "You are an experienced HR interviewer and industrial-organizational specialist. Generate practical, structured interview questions with evaluation rubrics.",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              role: { type: Type.STRING },
              focusArea: { type: Type.STRING },
              questions: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    category: { type: Type.STRING },
                    question: { type: Type.STRING },
                    whatToLookFor: { type: Type.STRING },
                  },
                  required: ["id", "category", "question", "whatToLookFor"],
                },
              },
            },
            required: ["role", "focusArea", "questions"],
          },
        },
      });

      const raw = (response.text ?? "{}").trim();
      const parsed = JSON.parse(raw);
      res.json(parsed);
    } catch (err) {
      handleApiError(res, err, "generate-questions");
    }
  });

  // Vite middleware in development, static files in production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== "true",
      },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, "dist");
    app.use(express.static(distDir));
    app.get("/{*splat}", (_req: Request, res: Response) => {
      res.sendFile(path.join(distDir, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`AI Recruitment Assistant running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
  process.exit(1);
});
